import React from 'react';
import { 
  Calendar, 
  MapPin, 
  Trophy, 
  Users, 
  ArrowUpRight, 
  Edit3, 
  Trash2, 
  Sparkles, 
  ShieldAlert,
  Globe,
  Tag
} from 'lucide-react';
import { Hackathon } from '../types/hackathon';
import { useAuth } from '../context/AuthContext';

interface HackathonCardProps {
  hackathon: Hackathon;
  onSelect: (hackathon: Hackathon) => void;
  onEdit: (hackathon: Hackathon) => void;
  onDelete: (hackathon: Hackathon) => void;
  isRegistered?: boolean;
}

export const HackathonCard: React.FC<HackathonCardProps> = ({
  hackathon,
  onSelect,
  onEdit,
  onDelete,
  isRegistered = false,
}) => {
  const { currentUser } = useAuth();
  const isOwner = currentUser && currentUser.uid === hackathon.organizerId;

  // Format date readable
  const formatDateRange = (startStr: string, endStr: string) => {
    try {
      const start = new Date(startStr);
      const end = new Date(endStr);
      const options: Intl.DateTimeFormatOptions = { month: 'short', day: 'numeric' };
      return `${start.toLocaleDateString(undefined, options)} - ${end.toLocaleDateString(undefined, options)}`;
    } catch {
      return `${startStr} - ${endStr}`;
    }
  };

  return (
    <div className="group relative rounded-2xl bg-[#0c101a] border border-gray-800/90 hover:border-red-500/50 hover:shadow-[0_0_25px_rgba(239,68,68,0.22)] transition-all duration-300 flex flex-col overflow-hidden">
      
      {/* Top Banner Image */}
      <div 
        onClick={() => onSelect(hackathon)}
        className="relative aspect-[16/9] w-full overflow-hidden bg-gray-900 cursor-pointer"
      >
        <img
          src={hackathon.bannerUrl || '/assets/aistudio/hackathon_98a10567.jpg'}
          alt={hackathon.title}
          onError={(e) => {
            (e.target as HTMLImageElement).src = '/assets/aistudio/hackathon_98a10567.jpg';
          }}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
        />

        <div className="absolute inset-0 bg-gradient-to-t from-[#0c101a] via-black/30 to-transparent" />

        {/* Top Badges overlay */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
          <div className="flex items-center gap-1.5 flex-wrap">
            {/* Category tag */}
            <span className="px-2.5 py-1 rounded-md text-[11px] font-mono-code font-semibold tracking-wider uppercase bg-black/70 backdrop-blur-md text-red-400 border border-red-500/30">
              {hackathon.category}
            </span>

            {/* Location Type */}
            <span className="px-2 py-1 rounded-md text-[10px] font-mono-code uppercase bg-gray-900/80 backdrop-blur-md text-gray-300 border border-gray-700">
              {hackathon.locationType}
            </span>
          </div>

          {/* Price Badge */}
          <div>
            {hackathon.price === 0 ? (
              <span className="px-2.5 py-1 rounded-md text-[11px] font-mono-code font-bold tracking-wide uppercase bg-emerald-950/80 backdrop-blur-md text-emerald-400 border border-emerald-500/40 shadow-sm">
                FREE
              </span>
            ) : (
              <span className="px-2.5 py-1 rounded-md text-[11px] font-mono-code font-bold tracking-wide bg-red-950/80 backdrop-blur-md text-red-400 border border-red-500/40">
                ${hackathon.price}
              </span>
            )}
          </div>
        </div>

        {/* If user is registered badge */}
        {isRegistered && (
          <div className="absolute bottom-3 left-3 px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[11px] font-mono-code font-semibold flex items-center gap-1">
            <span>✓ REGISTERED</span>
          </div>
        )}
      </div>

      {/* Card Content Body */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        
        <div>
          {/* Title */}
          <h3 
            onClick={() => onSelect(hackathon)}
            className="font-cyber font-bold text-lg text-white hover:text-red-400 transition-colors line-clamp-1 cursor-pointer"
          >
            {hackathon.title}
          </h3>

          {/* Tagline */}
          <p className="text-xs text-gray-400 line-clamp-2 mt-1.5 leading-relaxed font-sans">
            {hackathon.tagline || hackathon.description}
          </p>
        </div>

        {/* Details list */}
        <div className="space-y-2 pt-2 border-t border-gray-800/60 text-xs text-gray-300 font-mono-code">
          
          {/* Prize pool */}
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-gray-400">
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
              <span>Prize Pool</span>
            </span>
            <span className="font-semibold text-white font-cyber tracking-wide">
              {hackathon.prizePool || 'TBA'}
            </span>
          </div>

          {/* Dates */}
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-gray-400">
              <Calendar className="w-3.5 h-3.5 text-red-400" />
              <span>Schedule</span>
            </span>
            <span className="text-gray-300">
              {formatDateRange(hackathon.startDate, hackathon.endDate)}
            </span>
          </div>

          {/* Location */}
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-gray-400">
              {hackathon.locationType === 'online' ? (
                <Globe className="w-3.5 h-3.5 text-cyan-400" />
              ) : (
                <MapPin className="w-3.5 h-3.5 text-rose-400" />
              )}
              <span>Location</span>
            </span>
            <span className="text-gray-300 truncate max-w-[140px]">
              {hackathon.location}
            </span>
          </div>

          {/* Participants */}
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-gray-400">
              <Users className="w-3.5 h-3.5 text-purple-400" />
              <span>Participants</span>
            </span>
            <span className="text-gray-300">
              {hackathon.registeredCount || 0} registered
            </span>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="pt-3 border-t border-gray-800/80 flex items-center justify-between gap-2">
          {/* Owner Controls */}
          {isOwner ? (
            <div className="flex items-center gap-1.5">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onEdit(hackathon);
                }}
                title="Edit Hackathon"
                className="p-2 rounded-lg bg-gray-900 hover:bg-gray-800 text-gray-300 hover:text-white border border-gray-700 hover:border-red-500/40 transition-colors cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(hackathon);
                }}
                title="Delete Hackathon"
                className="p-2 rounded-lg bg-red-950/30 hover:bg-red-950/60 text-red-400 hover:text-red-300 border border-red-500/30 hover:border-red-500/60 transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
              <span className="text-[10px] uppercase font-mono-code text-red-400 bg-red-950/40 px-1.5 py-0.5 rounded border border-red-500/30">
                You Host
              </span>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-xs text-gray-400 truncate max-w-[170px]">
              {hackathon.organizerAvatar && (
                <img
                  src={hackathon.organizerAvatar}
                  alt={hackathon.organizerName}
                  className="w-5 h-5 rounded-full object-cover border border-gray-700"
                />
              )}
              <span className="truncate">{hackathon.organizerName}</span>
            </div>
          )}

          {/* View Details Button */}
          <button
            onClick={() => onSelect(hackathon)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-gray-900 group-hover:bg-red-600 text-gray-200 group-hover:text-white border border-gray-800 group-hover:border-red-500 text-xs font-medium transition-all cursor-pointer ml-auto shadow-sm"
          >
            <span>Details</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </div>
  );
};
