import React from 'react';
import { Terminal, PlusCircle, LogIn, LogOut, Calendar, ShieldCheck, User as UserIcon, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface NavbarProps {
  onOpenCreateModal: () => void;
  onOpenPresentationModal: () => void;
  currentView: 'explore' | 'dashboard';
  setCurrentView: (view: 'explore' | 'dashboard') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenCreateModal,
  onOpenPresentationModal,
  currentView,
  setCurrentView,
}) => {
  const { currentUser, signInWithGoogle, logout } = useAuth();
  const [dropdownOpen, setDropdownOpen] = React.useState(false);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-red-500/20 bg-[#090b10]/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        {/* Brand / Logo */}
        <div 
          onClick={() => setCurrentView('explore')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="relative flex items-center justify-center w-10 h-10 rounded-lg bg-red-950/60 border border-red-500/40 text-red-500 group-hover:border-red-400 group-hover:shadow-[0_0_15px_rgba(239,68,68,0.5)] transition-all">
            <Terminal className="w-5 h-5 text-red-400" />
            <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
            </span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-cyber font-bold text-xl tracking-wider text-white group-hover:text-red-400 transition-colors">
                HACK<span className="text-red-500">MATRIX</span>
              </span>
              <span className="text-[10px] uppercase tracking-widest px-1.5 py-0.5 rounded bg-red-500/10 border border-red-500/30 text-red-400 font-mono-code font-semibold">
                v2.6
              </span>
            </div>
            <p className="text-[11px] text-gray-400 hidden sm:block font-mono-code">
              Cyberpunk & AI Hackathons Hub
            </p>
          </div>
        </div>

        {/* Center Nav tabs */}
        <nav className="flex items-center gap-1 sm:gap-2 bg-gray-900/60 p-1 rounded-xl border border-gray-800">
          <button
            onClick={() => setCurrentView('explore')}
            className={`px-3 sm:px-4 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ${
              currentView === 'explore'
                ? 'bg-red-600/20 text-red-400 border border-red-500/30 shadow-sm'
                : 'text-gray-400 hover:text-gray-200 hover:bg-gray-800/50'
            }`}
          >
            Explore Events
          </button>
          <button
            onClick={() => {
              if (!currentUser) {
                signInWithGoogle();
              } else {
                setCurrentView('dashboard');
              }
            }}
            className={`px-3 sm:px-4 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all flex items-center gap-1.5 ${
              currentView === 'dashboard'
                ? 'bg-red-600/20 text-red-400 border border-red-500/30 shadow-sm'
                : 'text-gray-400 hover:text-gray-200 hover:bg-gray-800/50'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>My Events</span>
          </button>
          <button
            onClick={onOpenPresentationModal}
            className="px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-mono-code transition-all flex items-center gap-1.5 bg-red-950/40 hover:bg-red-950/80 text-red-400 hover:text-red-300 border border-red-500/40"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="font-semibold">Project PPT</span>
          </button>
          <a
            href="/HackMatrix_Complete_Project_Report_35_Pages.html"
            target="_blank"
            rel="noreferrer"
            title="Open Academic Project Report (AKTU Format)"
            className="hidden lg:flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-mono-code bg-red-950/40 hover:bg-red-900/60 text-red-300 border border-red-500/40"
          >
            <span>📄 Project Report</span>
          </a>
          <a
            href="/HackMatrix_Complete_Project_Presentation.html"
            download="HackMatrix_Complete_Project_Presentation.html"
            title="Download Complete 15-Page PPT HTML File"
            className="hidden xl:flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-mono-code bg-gray-900 hover:bg-gray-800 text-gray-300 hover:text-white border border-gray-700"
          >
            <span>📥 Download PPT</span>
          </a>
        </nav>

        {/* Right CTA / Auth */}
        <div className="flex items-center gap-3">
          {/* Host Hackathon Button */}
          <button
            onClick={() => {
              if (!currentUser) {
                signInWithGoogle();
              } else {
                onOpenCreateModal();
              }
            }}
            className="hidden md:flex items-center gap-2 px-3.5 py-2 rounded-lg bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-medium text-xs sm:text-sm shadow-[0_0_15px_rgba(239,68,68,0.3)] hover:shadow-[0_0_22px_rgba(239,68,68,0.5)] transition-all cursor-pointer border border-red-400/30"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Host Hackathon</span>
          </button>

          {/* User state */}
          {currentUser ? (
            <div className="relative">
              <button
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-lg bg-gray-900 border border-gray-800 hover:border-red-500/40 transition-all text-left"
              >
                {currentUser.photoURL ? (
                  <img
                    src={currentUser.photoURL}
                    alt={currentUser.displayName || 'User'}
                    className="w-7 h-7 rounded-full border border-red-500/50 object-cover"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-full bg-red-950/80 border border-red-500/40 flex items-center justify-center text-red-400">
                    <UserIcon className="w-4 h-4" />
                  </div>
                )}
                <span className="text-xs font-medium text-gray-200 hidden lg:inline max-w-[110px] truncate">
                  {currentUser.displayName || currentUser.email?.split('@')[0]}
                </span>
              </button>

              {dropdownOpen && (
                <div 
                  className="absolute right-0 mt-2 w-56 rounded-xl bg-[#0e121b] border border-red-500/30 shadow-2xl py-2 z-50 animate-in fade-in slide-in-from-top-2"
                  onMouseLeave={() => setDropdownOpen(false)}
                >
                  <div className="px-4 py-2 border-b border-gray-800">
                    <p className="text-xs font-semibold text-white truncate">
                      {currentUser.displayName || 'Active Hacker'}
                    </p>
                    <p className="text-[11px] text-gray-400 truncate font-mono-code">
                      {currentUser.email}
                    </p>
                  </div>

                  <div className="py-1">
                    <button
                      onClick={() => {
                        setCurrentView('dashboard');
                        setDropdownOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-gray-300 hover:bg-red-500/10 hover:text-red-400 flex items-center gap-2"
                    >
                      <Calendar className="w-3.5 h-3.5" />
                      <span>Manage My Hackathons</span>
                    </button>
                    <button
                      onClick={() => {
                        onOpenCreateModal();
                        setDropdownOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-gray-300 hover:bg-red-500/10 hover:text-red-400 flex items-center gap-2 md:hidden"
                    >
                      <PlusCircle className="w-3.5 h-3.5" />
                      <span>Host Hackathon</span>
                    </button>
                  </div>

                  <div className="border-t border-gray-800 pt-1">
                    <button
                      onClick={() => {
                        logout();
                        setDropdownOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs text-red-400 hover:bg-red-950/40 flex items-center gap-2"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={() => signInWithGoogle()}
              className="flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg bg-gray-900 hover:bg-gray-800 border border-gray-700 hover:border-red-500/40 text-gray-200 text-xs sm:text-sm font-medium transition-all shadow-sm"
            >
              <LogIn className="w-4 h-4 text-red-400" />
              <span>Sign In</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
