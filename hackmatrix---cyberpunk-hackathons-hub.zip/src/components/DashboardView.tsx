import React, { useState } from 'react';
import { 
  Calendar, 
  PlusCircle, 
  Trophy, 
  Users, 
  Edit3, 
  Trash2, 
  ArrowUpRight, 
  Sparkles, 
  Layers, 
  CheckCircle,
  ExternalLink,
  Shield
} from 'lucide-react';
import { Hackathon, HackathonRegistration } from '../types/hackathon';
import { useAuth } from '../context/AuthContext';
import { unregisterFromHackathon } from '../services/hackathonService';

interface DashboardViewProps {
  myHackathons: Hackathon[];
  myRegistrations: HackathonRegistration[];
  allHackathons: Hackathon[];
  onOpenCreateModal: () => void;
  onSelectHackathon: (hackathon: Hackathon) => void;
  onEditHackathon: (hackathon: Hackathon) => void;
  onDeleteHackathon: (hackathon: Hackathon) => void;
  onBackToExplore: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  myHackathons,
  myRegistrations,
  allHackathons,
  onOpenCreateModal,
  onSelectHackathon,
  onEditHackathon,
  onDeleteHackathon,
  onBackToExplore,
}) => {
  const { currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState<'hosted' | 'registered'>('hosted');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in">
      
      {/* User Header Profile Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-[#111724] to-[#0c101a] border border-red-500/30 shadow-[0_0_30px_rgba(239,68,68,0.15)] flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          {currentUser?.photoURL ? (
            <img
              src={currentUser.photoURL}
              alt={currentUser.displayName || 'User'}
              className="w-16 h-16 rounded-2xl border-2 border-red-500/50 object-cover shadow-lg"
            />
          ) : (
            <div className="w-16 h-16 rounded-2xl bg-red-950/80 border-2 border-red-500/50 flex items-center justify-center text-red-400 font-cyber text-2xl font-bold">
              {currentUser?.displayName?.[0] || currentUser?.email?.[0]?.toUpperCase() || 'H'}
            </div>
          )}

          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-extrabold font-cyber text-white">
                {currentUser?.displayName || 'Registered Hacker'}
              </h1>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono-code font-bold uppercase bg-red-500/20 text-red-400 border border-red-500/40">
                PRO BUILDER
              </span>
            </div>
            <p className="text-xs text-gray-400 font-mono-code">
              {currentUser?.email}
            </p>
          </div>
        </div>

        {/* Quick action: Host Hackathon */}
        <button
          onClick={onOpenCreateModal}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-semibold text-xs sm:text-sm shadow-[0_0_20px_rgba(239,68,68,0.4)] transition-all cursor-pointer border border-red-400/40"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Host New Hackathon</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center justify-between border-b border-gray-800 pb-3">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('hosted')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-medium transition-all cursor-pointer ${
              activeTab === 'hosted'
                ? 'bg-red-600/20 text-red-400 border border-red-500/40 font-semibold'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Hosted By Me ({myHackathons.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('registered')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-medium transition-all cursor-pointer ${
              activeTab === 'registered'
                ? 'bg-red-600/20 text-red-400 border border-red-500/40 font-semibold'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <CheckCircle className="w-4 h-4" />
            <span>My Registrations ({myRegistrations.length})</span>
          </button>
        </div>

        <button
          onClick={onBackToExplore}
          className="text-xs font-mono-code text-gray-400 hover:text-red-400 transition-colors"
        >
          ← Back to All Hackathons
        </button>
      </div>

      {/* Tab: Hosted Hackathons */}
      {activeTab === 'hosted' && (
        <div className="space-y-4">
          {myHackathons.length === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-[#0c101a] border border-gray-800 space-y-4">
              <div className="w-14 h-14 rounded-full bg-red-950/40 border border-red-500/30 flex items-center justify-center text-red-400 mx-auto">
                <PlusCircle className="w-7 h-7" />
              </div>
              <h3 className="text-lg font-cyber font-bold text-white">
                NO HACKATHONS HOSTED YET
              </h3>
              <p className="text-xs text-gray-400 max-w-md mx-auto leading-relaxed">
                You haven't created any hackathons yet. Launch your own event with custom branding, challenge tracks, prize pools, and instant public discovery.
              </p>
              <button
                onClick={onOpenCreateModal}
                className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-semibold shadow-md inline-flex items-center gap-2"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Host Your First Hackathon</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {myHackathons.map((hackathon) => (
                <div
                  key={hackathon.id}
                  className="rounded-2xl bg-[#0c101a] border border-red-500/30 hover:border-red-500/60 transition-all flex flex-col overflow-hidden shadow-lg"
                >
                  <div className="relative aspect-[16/9] w-full overflow-hidden bg-gray-950">
                    <img
                      src={hackathon.bannerUrl || '/assets/aistudio/hackathon_98a10567.jpg'}
                      alt={hackathon.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-black/80 text-[10px] font-mono-code text-red-400 border border-red-500/30">
                      {hackathon.category}
                    </div>
                    <div className="absolute top-2 right-2 px-2 py-0.5 rounded bg-black/80 text-[10px] font-mono-code text-white">
                      {hackathon.price === 0 ? 'FREE' : `$${hackathon.price}`}
                    </div>
                  </div>

                  <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                    <div>
                      <h4 className="font-cyber font-bold text-white text-base truncate">
                        {hackathon.title}
                      </h4>
                      <p className="text-xs text-gray-400 line-clamp-2 mt-1">
                        {hackathon.tagline || hackathon.description}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-gray-800 text-xs font-mono-code text-gray-300 flex items-center justify-between">
                      <span className="flex items-center gap-1.5 text-gray-400">
                        <Users className="w-3.5 h-3.5 text-cyan-400" />
                        <span>{hackathon.registeredCount || 0} participants</span>
                      </span>
                      <span className="text-amber-400 font-semibold">
                        {hackathon.prizePool}
                      </span>
                    </div>

                    <div className="pt-3 border-t border-gray-800 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => onEditHackathon(hackathon)}
                          className="p-2 rounded-lg bg-gray-900 hover:bg-gray-800 text-gray-200 border border-gray-700"
                          title="Edit Hackathon"
                        >
                          <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                        </button>
                        <button
                          onClick={() => onDeleteHackathon(hackathon)}
                          className="p-2 rounded-lg bg-red-950/40 hover:bg-red-950 text-red-400 border border-red-500/40"
                          title="Delete Hackathon"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <button
                        onClick={() => onSelectHackathon(hackathon)}
                        className="px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-white text-xs font-medium flex items-center gap-1"
                      >
                        <span>View Live</span>
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </button>
                    </div>

                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab: Registered Hackathons */}
      {activeTab === 'registered' && (
        <div className="space-y-4">
          {myRegistrations.length === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-[#0c101a] border border-gray-800 space-y-4">
              <div className="w-14 h-14 rounded-full bg-emerald-950/40 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mx-auto">
                <CheckCircle className="w-7 h-7" />
              </div>
              <h3 className="text-lg font-cyber font-bold text-white">
                NO ACTIVE REGISTRATIONS
              </h3>
              <p className="text-xs text-gray-400 max-w-md mx-auto leading-relaxed">
                You haven't registered for any hackathons yet. Explore our open cybersecurity and AI sprints and secure your participant badge with 1 click!
              </p>
              <button
                onClick={onBackToExplore}
                className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-semibold shadow-md inline-flex items-center gap-2"
              >
                <span>Browse Hackathons</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {myRegistrations.map((reg) => {
                const targetHackathon = allHackathons.find((h) => h.id === reg.hackathonId);
                return (
                  <div
                    key={reg.id}
                    className="rounded-2xl bg-[#0c101a] border border-emerald-500/30 hover:border-emerald-500/60 transition-all flex flex-col overflow-hidden shadow-lg"
                  >
                    <div className="relative aspect-[16/9] w-full overflow-hidden bg-gray-950">
                      <img
                        src={reg.hackathonBanner || targetHackathon?.bannerUrl || '/assets/aistudio/hackathon_98a10567.jpg'}
                        alt={reg.hackathonTitle || 'Hackathon'}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-emerald-950/90 text-[10px] font-mono-code text-emerald-400 border border-emerald-500/40 font-bold">
                        ✓ CONFIRMED SPOT
                      </div>
                    </div>

                    <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                      <div>
                        <h4 className="font-cyber font-bold text-white text-base truncate">
                          {reg.hackathonTitle || targetHackathon?.title || 'Registered Hackathon'}
                        </h4>
                        <div className="mt-1 text-xs text-gray-400 font-mono-code space-y-0.5">
                          <p>Team: <strong className="text-white">{reg.teamName || 'Solo Hacker'}</strong></p>
                          <p>Starts: <span className="text-red-400">{reg.hackathonStartDate || targetHackathon?.startDate}</span></p>
                        </div>
                      </div>

                      <div className="pt-3 border-t border-gray-800 flex items-center justify-between gap-2">
                        <button
                          onClick={async () => {
                            if (confirm('Cancel your registration for this hackathon?')) {
                              await unregisterFromHackathon(reg.id, reg.hackathonId);
                            }
                          }}
                          className="px-3 py-1.5 rounded-lg bg-gray-900 hover:bg-red-950/40 text-gray-400 hover:text-red-400 text-xs border border-gray-800"
                        >
                          Unregister
                        </button>

                        {targetHackathon && (
                          <button
                            onClick={() => onSelectHackathon(targetHackathon)}
                            className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium flex items-center gap-1"
                          >
                            <span>View Event</span>
                            <ArrowUpRight className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

    </div>
  );
};
