import React from 'react';
import { Terminal, Shield, Zap, Flame, Trophy, Globe, ArrowRight, Play } from 'lucide-react';

interface HeroSectionProps {
  onExploreClick: () => void;
  onHostClick: () => void;
  hackathonsCount: number;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onExploreClick,
  onHostClick,
  hackathonsCount,
}) => {
  return (
    <section className="relative overflow-hidden pt-8 pb-12 lg:pt-12 lg:pb-16 cyber-grid-bg border-b border-red-500/15">
      {/* Ambient background glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[350px] bg-red-600/10 blur-[130px] pointer-events-none rounded-full" />
      <div className="absolute -top-24 right-10 w-[300px] h-[300px] bg-rose-600/10 blur-[100px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Column: Headlines & Call to Action */}
          <div className="lg:col-span-7 space-y-6">
            {/* Live Terminal status badge */}
            <div className="inline-flex items-center gap-2.5 px-3 py-1.5 rounded-full bg-red-950/40 border border-red-500/30 text-xs font-mono-code text-red-400">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
              </span>
              <span>GRID PROTOCOL ACTIVE</span>
              <span className="text-gray-500">•</span>
              <span className="text-gray-300">REALTIME FIRESTORE SYNC</span>
            </div>

            <div className="space-y-3">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.1]">
                ENTER THE <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-rose-500 to-amber-500 font-cyber">HACK MATRIX</span>
              </h1>
              <p className="text-base sm:text-lg text-gray-300 max-w-2xl font-normal leading-relaxed">
                The premier hub to discover, host, and conquer elite hackathons in <span className="text-red-400 font-medium">Artificial Intelligence</span>, <span className="text-red-400 font-medium">Cybersecurity</span>, and <span className="text-red-400 font-medium">Autonomous Systems</span>.
              </p>
            </div>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onExploreClick}
                className="flex items-center gap-2.5 px-6 py-3 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-semibold text-sm shadow-[0_0_20px_rgba(239,68,68,0.35)] hover:shadow-[0_0_30px_rgba(239,68,68,0.6)] transition-all cursor-pointer border border-red-400/40"
              >
                <span>Browse Hackathons</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onHostClick}
                className="flex items-center gap-2 px-5 py-3 rounded-xl bg-[#0f1422] hover:bg-[#161d2f] text-gray-200 hover:text-white font-medium text-sm border border-red-500/30 hover:border-red-500/60 transition-all cursor-pointer"
              >
                <Flame className="w-4 h-4 text-red-500" />
                <span>Host Your Event</span>
              </button>
            </div>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-3 gap-3 pt-4 border-t border-gray-800/80">
              <div className="p-3 rounded-lg bg-gray-900/50 border border-gray-800">
                <div className="flex items-center gap-1.5 text-xs text-gray-400 font-mono-code mb-1">
                  <Trophy className="w-3.5 h-3.5 text-amber-400" />
                  <span>PRIZE POOL</span>
                </div>
                <div className="text-xl sm:text-2xl font-bold font-cyber text-white">
                  $315K+
                </div>
              </div>

              <div className="p-3 rounded-lg bg-gray-900/50 border border-gray-800">
                <div className="flex items-center gap-1.5 text-xs text-gray-400 font-mono-code mb-1">
                  <Zap className="w-3.5 h-3.5 text-red-400" />
                  <span>ACTIVE EVENTS</span>
                </div>
                <div className="text-xl sm:text-2xl font-bold font-cyber text-white">
                  {hackathonsCount || 5}
                </div>
              </div>

              <div className="p-3 rounded-lg bg-gray-900/50 border border-gray-800">
                <div className="flex items-center gap-1.5 text-xs text-gray-400 font-mono-code mb-1">
                  <Globe className="w-3.5 h-3.5 text-cyan-400" />
                  <span>COMMUNITY</span>
                </div>
                <div className="text-xl sm:text-2xl font-bold font-cyber text-white">
                  2,400+
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Cyberpunk Battlestation Showcase */}
          <div className="lg:col-span-5">
            <div className="relative group">
              {/* Outer decorative brackets */}
              <div className="absolute -top-2 -left-2 w-4 h-4 border-t-2 border-l-2 border-red-500 z-10" />
              <div className="absolute -top-2 -right-2 w-4 h-4 border-t-2 border-r-2 border-red-500 z-10" />
              <div className="absolute -bottom-2 -left-2 w-4 h-4 border-b-2 border-l-2 border-red-500 z-10" />
              <div className="absolute -bottom-2 -right-2 w-4 h-4 border-b-2 border-r-2 border-red-500 z-10" />

              {/* Glowing Card Frame */}
              <div className="relative rounded-2xl overflow-hidden border border-red-500/40 bg-[#0c101a] shadow-[0_0_35px_rgba(239,68,68,0.25)] group-hover:shadow-[0_0_45px_rgba(239,68,68,0.4)] transition-all">
                
                {/* Visual Header / Terminal bar */}
                <div className="flex items-center justify-between px-3.5 py-2 bg-[#080b12] border-b border-red-500/30 text-[11px] font-mono-code text-gray-400">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500/80 inline-block"></span>
                    <span className="text-red-400">BATTLESTATION_NODE://0x98a1</span>
                  </div>
                  <span className="text-gray-500">LIVE FEED</span>
                </div>

                {/* Main Hero Image from User attachment */}
                <div className="relative aspect-[4/5] sm:aspect-[16/11] lg:aspect-[4/5] max-h-[460px] w-full overflow-hidden">
                  <img
                    src="/assets/aistudio/hackathon_98a10567.jpg"
                    alt="Cyberpunk Hacker Battlestation"
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                  />
                  
                  {/* Subtle scanline & gradient overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#090b10] via-transparent to-black/20" />

                  {/* Floating Telemetry Box */}
                  <div className="absolute bottom-3 left-3 right-3 p-3.5 rounded-xl bg-black/75 backdrop-blur-md border border-red-500/30">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[10px] uppercase font-mono-code tracking-wider text-red-400 bg-red-950/60 px-2 py-0.5 rounded border border-red-500/40">
                        FLAGSHIP HACKATHON
                      </span>
                      <span className="text-xs font-mono-code text-emerald-400 font-semibold">
                        REGISTER NOW
                      </span>
                    </div>
                    <h3 className="font-cyber font-bold text-base text-white truncate">
                      CYBERSTORM 2026: Offensive AI Sprint
                    </h3>
                    <p className="text-xs text-gray-400 truncate mt-0.5 font-mono-code">
                      Red-team vs autonomous agents • $75,000 Prize Pool
                    </p>
                  </div>
                </div>

              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
