import React, { useState, useEffect } from 'react';
import { 
  X, 
  ChevronLeft, 
  ChevronRight, 
  Maximize2, 
  Minimize2, 
  Printer, 
  Presentation, 
  Layers, 
  Database, 
  ShieldCheck, 
  Cpu, 
  Terminal, 
  Flame, 
  Users, 
  ArrowRight,
  Sparkles,
  Download
} from 'lucide-react';

interface Slide {
  id: number;
  title: string;
  subtitle: string;
  category: string;
  content: React.ReactNode;
  speakerNotes: string;
}

export const PresentationModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({
  isOpen,
  onClose,
}) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === 'Space') {
        setCurrentSlide((prev) => Math.min(prev + 1, slides.length - 1));
      } else if (e.key === 'ArrowLeft') {
        setCurrentSlide((prev) => Math.max(prev - 1, 0));
      } else if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen]);

  if (!isOpen) return null;

  const slides: Slide[] = [
    {
      id: 1,
      category: 'PROJECT OVERVIEW',
      title: 'HACKMATRIX',
      subtitle: 'Modern Cyberpunk Hackathon Listing & Realtime Management Platform',
      content: (
        <div className="flex flex-col items-center justify-center text-center space-y-6 py-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-950/60 border border-red-500/40 text-red-400 font-mono-code text-xs">
            <Terminal className="w-3.5 h-3.5" />
            <span>FULL-STACK WEB & DATABASE APPLICATION</span>
          </div>

          <h1 className="text-4xl sm:text-5xl font-black font-cyber text-white tracking-wide">
            HACK<span className="text-red-500">MATRIX</span>
          </h1>

          <p className="text-base sm:text-lg text-gray-300 max-w-2xl leading-relaxed">
            A next-generation platform for discovering, hosting, and managing AI, cybersecurity, and engineering hackathons worldwide with real-time Firestore database synchronization.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 w-full max-w-2xl pt-4">
            <div className="p-3 rounded-xl bg-gray-900/60 border border-gray-800">
              <span className="text-[10px] text-gray-400 font-mono-code block">FRONTEND</span>
              <span className="text-sm font-bold text-white">React 19 + Tailwind</span>
            </div>
            <div className="p-3 rounded-xl bg-gray-900/60 border border-gray-800">
              <span className="text-[10px] text-gray-400 font-mono-code block">DATABASE</span>
              <span className="text-sm font-bold text-red-400">Cloud Firestore</span>
            </div>
            <div className="p-3 rounded-xl bg-gray-900/60 border border-gray-800">
              <span className="text-[10px] text-gray-400 font-mono-code block">AUTH</span>
              <span className="text-sm font-bold text-emerald-400">Google OAuth 2.0</span>
            </div>
            <div className="p-3 rounded-xl bg-gray-900/60 border border-gray-800">
              <span className="text-[10px] text-gray-400 font-mono-code block">ARCHITECTURE</span>
              <span className="text-sm font-bold text-cyan-400">Realtime WebSocket</span>
            </div>
          </div>
        </div>
      ),
      speakerNotes: 'Slide 1: Title slide introducing project title, core stack, and real-time database architecture.',
    },
    {
      id: 2,
      category: 'BACKGROUND & PROBLEM',
      title: 'Problem Statement & Market Need',
      subtitle: 'Why existing hackathon platforms fall short for modern developers',
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          <div className="space-y-4 text-xs sm:text-sm text-gray-300 leading-relaxed">
            <div className="p-3.5 rounded-xl bg-red-950/20 border border-red-500/30 space-y-1">
              <h4 className="font-bold text-red-400 font-cyber">1. Fragmented Event Discovery</h4>
              <p className="text-gray-400 text-xs">Hackathons are scattered across discordant platforms, Slack channels, and social media without a centralized high-tech hub.</p>
            </div>
            <div className="p-3.5 rounded-xl bg-red-950/20 border border-red-500/30 space-y-1">
              <h4 className="font-bold text-red-400 font-cyber">2. Stale, Static Data & Delay</h4>
              <p className="text-gray-400 text-xs">Most listing sites require manual refreshes; participants never know real-time seat availability or schedule alterations.</p>
            </div>
            <div className="p-3.5 rounded-xl bg-red-950/20 border border-red-500/30 space-y-1">
              <h4 className="font-bold text-red-400 font-cyber">3. Friction in Organizer Workflow</h4>
              <p className="text-gray-400 text-xs">Hosting a hackathon involves tedious approvals and complex forms instead of instant, self-service publishing.</p>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-[#080b12] border border-gray-800 space-y-3 font-mono-code text-xs">
            <div className="flex items-center justify-between text-gray-500 border-b border-gray-800 pb-2">
              <span>TRADITIONAL PLATFORMS</span>
              <span className="text-red-500">INEFFICIENT</span>
            </div>
            <ul className="space-y-2 text-gray-400">
              <li className="flex items-center gap-2 text-red-400">
                <span>✕</span> <span>Generic, corporate, boring UI</span>
              </li>
              <li className="flex items-center gap-2 text-red-400">
                <span>✕</span> <span>No instant live database sync</span>
              </li>
              <li className="flex items-center gap-2 text-red-400">
                <span>✕</span> <span>Complex multi-step signup barriers</span>
              </li>
              <li className="flex items-center gap-2 text-red-400">
                <span>✕</span> <span>No dedicated cyberpunk/tech identity</span>
              </li>
            </ul>
          </div>
        </div>
      ),
      speakerNotes: 'Slide 2: Explains the fragmentation and latency issues with existing hackathon portals.',
    },
    {
      id: 3,
      category: 'PROPOSED SOLUTION',
      title: 'The HackMatrix Solution',
      subtitle: 'A high-performance, real-time, developer-centric ecosystem',
      content: (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-[#0e121b] border border-red-500/30 space-y-2">
            <div className="w-9 h-9 rounded-lg bg-red-950/70 border border-red-500/40 flex items-center justify-center text-red-400">
              <Database className="w-5 h-5" />
            </div>
            <h4 className="font-cyber font-bold text-white text-sm">Real-time Cloud Database</h4>
            <p className="text-xs text-gray-400 leading-relaxed">
              Every created, edited, or deleted hackathon is synced in milliseconds across all browsers via Firebase Firestore WebSockets.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#0e121b] border border-red-500/30 space-y-2">
            <div className="w-9 h-9 rounded-lg bg-emerald-950/70 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h4 className="font-cyber font-bold text-white text-sm">Zero-Friction Google Auth</h4>
            <p className="text-xs text-gray-400 leading-relaxed">
              One-click Google authentication with automated profile tracking, secure RBAC permissions, and verified builder badges.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#0e121b] border border-red-500/30 space-y-2">
            <div className="w-9 h-9 rounded-lg bg-rose-950/70 border border-rose-500/40 flex items-center justify-center text-rose-400">
              <Cpu className="w-5 h-5" />
            </div>
            <h4 className="font-cyber font-bold text-white text-sm">Cyberpunk Command Center</h4>
            <p className="text-xs text-gray-400 leading-relaxed">
              Inspired by futuristic hacker battlestations with live countdown timers, telemetry feeds, and immersive visual hierarchy.
            </p>
          </div>
        </div>
      ),
      speakerNotes: 'Slide 3: High-level solution pillars: real-time cloud data, Google auth, and cyberpunk UX.',
    },
    {
      id: 4,
      category: 'CORE MODULES',
      title: 'Key Functional Modules',
      subtitle: 'Modular architecture designed for rapid scaling and high usability',
      content: (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-gray-900/50 border border-gray-800 space-y-1">
            <span className="font-cyber font-bold text-red-400 block">1. EXPLORE & FILTER</span>
            <p className="text-gray-400 text-[11px]">Multi-faceted search, category chips, format toggles (online/in-person), and price filters.</p>
          </div>
          <div className="p-3 rounded-xl bg-gray-900/50 border border-gray-800 space-y-1">
            <span className="font-cyber font-bold text-red-400 block">2. EVENT DETAILS MODAL</span>
            <p className="text-gray-400 text-[11px]">Live countdown to sprint start, prize tiers, rules, track focus, and direct share link.</p>
          </div>
          <div className="p-3 rounded-xl bg-gray-900/50 border border-gray-800 space-y-1">
            <span className="font-cyber font-bold text-red-400 block">3. 1-CLICK REGISTRATION</span>
            <p className="text-gray-400 text-[11px]">Instant participation enrollment with team name, Discord handle, and level tagging.</p>
          </div>
          <div className="p-3 rounded-xl bg-gray-900/50 border border-gray-800 space-y-1">
            <span className="font-cyber font-bold text-red-400 block">4. ORGANIZER CRUD HUB</span>
            <p className="text-gray-400 text-[11px]">Add, edit, and delete events with custom banner uploads, fee settings, and date validation.</p>
          </div>
          <div className="p-3 rounded-xl bg-gray-900/50 border border-gray-800 space-y-1">
            <span className="font-cyber font-bold text-red-400 block">5. HACKER DASHBOARD</span>
            <p className="text-gray-400 text-[11px]">Personalized tabbed workspace tracking hosted hackathons vs. enrolled registrations.</p>
          </div>
          <div className="p-3 rounded-xl bg-gray-900/50 border border-gray-800 space-y-1">
            <span className="font-cyber font-bold text-red-400 block">6. SECURITY & AUDITING</span>
            <p className="text-gray-400 text-[11px]">Server-side rule enforcement ensuring only owners can edit/delete their listings.</p>
          </div>
        </div>
      ),
      speakerNotes: 'Slide 4: Overview of all 6 functional pillars and operational capabilities.',
    },
    {
      id: 5,
      category: 'SYSTEM ARCHITECTURE',
      title: 'High-Level Architecture Diagram',
      subtitle: 'Client-to-Cloud Realtime Architecture with Firebase & React',
      content: (
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-[#080b12] border border-red-500/30 font-mono-code text-xs text-center overflow-x-auto">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-2 max-w-xl mx-auto">
              {/* Client Box */}
              <div className="p-3 rounded-lg bg-gray-900 border border-gray-700 w-full sm:w-44 text-left">
                <span className="text-red-400 font-bold block">CLIENT TIER</span>
                <span className="text-[10px] text-gray-400">React 19 SPA</span>
                <span className="text-[10px] text-gray-400 block">Tailwind CSS + Lucide</span>
                <span className="text-[10px] text-cyan-400 block">Auth Context / Hooks</span>
              </div>

              <div className="text-red-500 font-bold text-lg">⇄</div>

              {/* Service Box */}
              <div className="p-3 rounded-lg bg-gray-900 border border-gray-700 w-full sm:w-44 text-left">
                <span className="text-amber-400 font-bold block">SERVICE LAYER</span>
                <span className="text-[10px] text-gray-400">Firebase SDK Client</span>
                <span className="text-[10px] text-gray-400 block">Google Auth Provider</span>
                <span className="text-[10px] text-gray-400 block">onSnapshot WebSockets</span>
              </div>

              <div className="text-red-500 font-bold text-lg">⇄</div>

              {/* Cloud Box */}
              <div className="p-3 rounded-lg bg-red-950/40 border border-red-500/50 w-full sm:w-44 text-left">
                <span className="text-white font-bold block">CLOUD BACKEND</span>
                <span className="text-[10px] text-red-400 block">Cloud Firestore</span>
                <span className="text-[10px] text-gray-400 block">Firebase Auth Engine</span>
                <span className="text-[10px] text-emerald-400 block">firestore.rules ABAC</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-gray-400">
            <p>• <strong>Zero Polling:</strong> Firestore uses long-lived streaming WebSockets to push document diffs directly to the client.</p>
            <p>• <strong>Optimistic UI:</strong> Mutations render without waiting for server roundtrips, backed by local indexedDB caching.</p>
          </div>
        </div>
      ),
      speakerNotes: 'Slide 5: Explains the multi-tier client-to-cloud architecture and streaming WebSockets.',
    },
    {
      id: 6,
      category: 'DATABASE DESIGN',
      title: 'Database Schema & ER Diagram',
      subtitle: 'NoSQL Firestore Collection Models & Relationships',
      content: (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono-code">
          {/* Collection 1 */}
          <div className="p-3.5 rounded-xl bg-[#090d16] border border-red-500/30 space-y-2">
            <div className="flex items-center justify-between border-b border-gray-800 pb-1.5">
              <span className="text-red-400 font-bold font-cyber text-sm">COLLECTION: /hackathons</span>
              <span className="text-[10px] text-gray-500">Document ID: Auto</span>
            </div>
            <ul className="space-y-1 text-gray-300 text-[11px]">
              <li><strong className="text-white">title</strong>: string (max 150)</li>
              <li><strong className="text-white">tagline</strong>: string (max 250)</li>
              <li><strong className="text-white">description</strong>: string (max 10000)</li>
              <li><strong className="text-white">category</strong>: 'AI & ML' | 'Cybersecurity' | ...</li>
              <li><strong className="text-white">locationType</strong>: 'online' | 'in-person' | 'hybrid'</li>
              <li><strong className="text-white">price</strong>: number (0 = Free)</li>
              <li><strong className="text-white">prizePool</strong>: string (e.g. '$75,000')</li>
              <li><strong className="text-white">organizerId</strong>: string (UID foreign key)</li>
              <li><strong className="text-white">registeredCount</strong>: number</li>
            </ul>
          </div>

          {/* Collection 2 */}
          <div className="p-3.5 rounded-xl bg-[#090d16] border border-emerald-500/30 space-y-2">
            <div className="flex items-center justify-between border-b border-gray-800 pb-1.5">
              <span className="text-emerald-400 font-cyber font-bold text-sm">COLLECTION: /registrations</span>
              <span className="text-[10px] text-gray-500">ID: userId_hackathonId</span>
            </div>
            <ul className="space-y-1 text-gray-300 text-[11px]">
              <li><strong className="text-white">hackathonId</strong>: string (Ref to hackathon)</li>
              <li><strong className="text-white">userId</strong>: string (Ref to user auth)</li>
              <li><strong className="text-white">userName</strong>: string</li>
              <li><strong className="text-white">userEmail</strong>: string</li>
              <li><strong className="text-white">teamName</strong>: string</li>
              <li><strong className="text-white">discordHandle</strong>: string</li>
              <li><strong className="text-white">experienceLevel</strong>: string</li>
              <li><strong className="text-white">registeredAt</strong>: ISO Timestamp</li>
            </ul>
          </div>
        </div>
      ),
      speakerNotes: 'Slide 6: Details the database entity models, field definitions, and foreign key relationships.',
    },
    {
      id: 7,
      category: 'DESIGN PHILOSOPHY',
      title: 'UI/UX & Cyberpunk Aesthetic',
      subtitle: 'Crafted around the user-provided Battlestation artwork',
      content: (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
          <div className="relative rounded-xl overflow-hidden border border-red-500/40 aspect-[16/10] bg-black">
            <img
              src="/assets/aistudio/hackathon_98a10567.jpg"
              alt="Design Reference Artwork"
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-black/80 text-[10px] font-mono-code text-red-400 border border-red-500/30">
              REFERENCE ARTWORK APPLIED
            </div>
          </div>

          <div className="space-y-3 text-xs text-gray-300">
            <div className="p-2.5 rounded-lg bg-gray-900 border border-gray-800">
              <strong className="text-red-400 font-cyber block">Color Palette:</strong>
              <p className="text-[11px] text-gray-400">Carbon Obsidian (#07090e), Terminal Crimson (#ef4444), Neon Scarlet, and Dark Slate.</p>
            </div>
            <div className="p-2.5 rounded-lg bg-gray-900 border border-gray-800">
              <strong className="text-red-400 font-cyber block">Typography:</strong>
              <p className="text-[11px] text-gray-400">Chakra Petch (futuristic headings), JetBrains Mono (telemetry badges), Plus Jakarta Sans (body).</p>
            </div>
            <div className="p-2.5 rounded-lg bg-gray-900 border border-gray-800">
              <strong className="text-red-400 font-cyber block">Visual Discipline:</strong>
              <p className="text-[11px] text-gray-400">Subtle scanline overlays, glowing LED status pings, and glassmorphic HUD borders.</p>
            </div>
          </div>
        </div>
      ),
      speakerNotes: 'Slide 7: Explains how the reference artwork drove the color theory and cyberpunk aesthetics.',
    },
    {
      id: 8,
      category: 'USER LIFECYCLE',
      title: 'User Journey & Interaction Flowchart',
      subtitle: 'From discovery to registration and event organization',
      content: (
        <div className="p-4 rounded-xl bg-[#080b12] border border-red-500/30 space-y-3 font-mono-code text-xs">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-center">
            <div className="p-2.5 rounded-lg bg-gray-900 border border-gray-700 w-full sm:w-36">
              <span className="text-white font-bold block">1. BROWSE</span>
              <span className="text-[10px] text-gray-400">Filter & Search</span>
            </div>
            <span className="text-red-500">→</span>
            <div className="p-2.5 rounded-lg bg-gray-900 border border-gray-700 w-full sm:w-36">
              <span className="text-amber-400 font-bold block">2. AUTHENTICATE</span>
              <span className="text-[10px] text-gray-400">Google OAuth</span>
            </div>
            <span className="text-red-500">→</span>
            <div className="p-2.5 rounded-lg bg-gray-900 border border-gray-700 w-full sm:w-36">
              <span className="text-emerald-400 font-bold block">3. REGISTER</span>
              <span className="text-[10px] text-gray-400">Join Solo / Team</span>
            </div>
            <span className="text-red-500">→</span>
            <div className="p-2.5 rounded-lg bg-red-950/40 border border-red-500/50 w-full sm:w-36">
              <span className="text-white font-bold block">4. HOST & MANAGE</span>
              <span className="text-[10px] text-red-400">Create / Edit / Del</span>
            </div>
          </div>

          <div className="pt-2 text-gray-400 text-xs">
            <p>• <strong>State Transitions:</strong> When a user logs in, the navigation dynamically adapts from "Sign In" to an account avatar dropdown with quick access to hosted hackathons and enrolled registrations.</p>
          </div>
        </div>
      ),
      speakerNotes: 'Slide 8: Walkthrough of the complete user onboarding and participation flow.',
    },
    {
      id: 9,
      category: 'CRUD LOGIC',
      title: 'Organizer Management Workflow',
      subtitle: 'Complete Create, Read, Update, and Delete capabilities',
      content: (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-gray-900 border border-gray-800 space-y-1">
            <span className="text-emerald-400 font-cyber font-bold block">CREATE (ADD)</span>
            <p className="text-gray-400 text-[11px]">Upload custom banner or select presets, set registration price ($0 or custom), pick venue type and dates.</p>
          </div>
          <div className="p-3 rounded-xl bg-gray-900 border border-gray-800 space-y-1">
            <span className="text-cyan-400 font-cyber font-bold block">READ (EXPLORE)</span>
            <p className="text-gray-400 text-[11px]">Public real-time query of all active hackathons with sorting, multi-tag filters, and detail modals.</p>
          </div>
          <div className="p-3 rounded-xl bg-gray-900 border border-gray-800 space-y-1">
            <span className="text-amber-400 font-cyber font-bold block">UPDATE (EDIT)</span>
            <p className="text-gray-400 text-[11px]">Organizers can modify prize pools, dates, rules, or taglines anytime. Immediate live client update.</p>
          </div>
          <div className="p-3 rounded-xl bg-gray-900 border border-gray-800 space-y-1">
            <span className="text-red-400 font-cyber font-bold block">DELETE</span>
            <p className="text-gray-400 text-[11px]">Two-step confirmation modal to prevent accidental data loss. Permanently erased from Firestore.</p>
          </div>
        </div>
      ),
      speakerNotes: 'Slide 9: Explains the lifecycle of hackathon management by verified organizers.',
    },
    {
      id: 10,
      category: 'SECURITY & GOVERNANCE',
      title: 'Firestore Security & Access Control',
      subtitle: 'Zero-Trust Attribute-Based Access Control (ABAC)',
      content: (
        <div className="space-y-3 text-xs font-mono-code">
          <div className="p-3 rounded-xl bg-[#080b12] border border-red-500/30 text-gray-300 space-y-1.5">
            <div className="text-red-400 font-bold font-cyber text-sm">SECURITY ENFORCEMENT RULES</div>
            <p className="text-gray-400 text-[11px]">
              • <strong>Public Read:</strong> Anyone can browse hackathons without authentication.<br />
              • <strong>Verified Writes:</strong> Creating a hackathon requires <code>isSignedIn()</code> and checks incoming schema boundaries.<br />
              • <strong>Owner Isolation:</strong> Only the original creator (<code>existing().organizerId == request.auth.uid</code>) can edit or delete an event.<br />
              • <strong>Registration Privacy:</strong> Users can only create and cancel registrations matching their own verified <code>auth.uid</code>.
            </p>
          </div>

          <div className="p-3 rounded-xl bg-gray-900 border border-gray-800 text-[11px] text-gray-400">
            <strong className="text-white">Deployed Rules Version:</strong> Cloud Firestore Security Rules v2 with zero security vulnerabilities.
          </div>
        </div>
      ),
      speakerNotes: 'Slide 10: Details how security rules protect user data against unauthorized edits or deletions.',
    },
    {
      id: 11,
      category: 'REALTIME ENGINE',
      title: 'Real-Time Sync Mechanics',
      subtitle: 'How Firestore onSnapshot powers instant live reactivity',
      content: (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center text-xs">
          <div className="p-4 rounded-xl bg-[#090d16] border border-cyan-500/30 space-y-2 font-mono-code">
            <span className="text-cyan-400 font-bold block">THE LISTENER LIFECYCLE</span>
            <p className="text-gray-300 text-[11px]">1. <code>subscribeToHackathons()</code> mounts on app boot.</p>
            <p className="text-gray-300 text-[11px]">2. Bi-directional WebSocket stream connects to Firestore.</p>
            <p className="text-gray-300 text-[11px]">3. Server pushes instant delta payloads on any write.</p>
            <p className="text-gray-300 text-[11px]">4. React state updates, triggering frictionless re-render.</p>
          </div>

          <div className="space-y-2 text-gray-300">
            <div className="p-3 rounded-xl bg-gray-900 border border-gray-800">
              <strong className="text-white block font-cyber">No Page Refresh Needed:</strong>
              <p className="text-gray-400 text-xs">If Organizer A edits a prize in Tokyo, Participant B in New York sees the new prize on their screen instantly.</p>
            </div>
            <div className="p-3 rounded-xl bg-gray-900 border border-gray-800">
              <strong className="text-white block font-cyber">Offline Tolerant:</strong>
              <p className="text-gray-400 text-xs">Temporary network disruptions resume seamlessly with cached snapshot playback.</p>
            </div>
          </div>
        </div>
      ),
      speakerNotes: 'Slide 11: Explains the WebSocket push mechanism and sub-second multi-user synchronization.',
    },
    {
      id: 12,
      category: 'TECH STACK',
      title: 'Complete Technology Stack',
      subtitle: 'Modern, scalable libraries and production tools',
      content: (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono-code">
          <div className="p-3 rounded-xl bg-gray-900 border border-gray-800">
            <span className="text-red-400 font-bold block">CORE FRAMEWORK</span>
            <span className="text-white text-sm font-cyber font-bold">React 19</span>
            <span className="text-[10px] text-gray-500 block mt-1">Vite 8 + TypeScript</span>
          </div>

          <div className="p-3 rounded-xl bg-gray-900 border border-gray-800">
            <span className="text-cyan-400 font-bold block">STYLING ENGINE</span>
            <span className="text-white text-sm font-cyber font-bold">Tailwind CSS 4</span>
            <span className="text-[10px] text-gray-500 block mt-1">@tailwindcss/vite</span>
          </div>

          <div className="p-3 rounded-xl bg-gray-900 border border-gray-800">
            <span className="text-amber-400 font-bold block">CLOUD BACKEND</span>
            <span className="text-white text-sm font-cyber font-bold">Cloud Firestore</span>
            <span className="text-[10px] text-gray-500 block mt-1">Enterprise Edition</span>
          </div>

          <div className="p-3 rounded-xl bg-gray-900 border border-gray-800">
            <span className="text-emerald-400 font-bold block">AUTHENTICATION</span>
            <span className="text-white text-sm font-cyber font-bold">Firebase Auth</span>
            <span className="text-[10px] text-gray-500 block mt-1">Google OAuth Provider</span>
          </div>
        </div>
      ),
      speakerNotes: 'Slide 12: Detailed breakdown of the technical dependencies and versions.',
    },
    {
      id: 13,
      category: 'TESTING & METRICS',
      title: 'Performance & Verification Metrics',
      subtitle: 'Benchmarking latency, security, and responsive layouts',
      content: (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
          <div className="p-4 rounded-xl bg-[#0e121b] border border-gray-800">
            <span className="text-2xl font-black font-cyber text-emerald-400">&lt; 150ms</span>
            <span className="text-xs text-gray-300 font-bold block mt-1">Sync Latency</span>
            <p className="text-[10px] text-gray-500 mt-1">From Firestore write to client render</p>
          </div>

          <div className="p-4 rounded-xl bg-[#0e121b] border border-gray-800">
            <span className="text-2xl font-black font-cyber text-cyan-400">100%</span>
            <span className="text-xs text-gray-300 font-bold block mt-1">TypeScript Strict</span>
            <p className="text-[10px] text-gray-500 mt-1">0 compilation or linting errors</p>
          </div>

          <div className="p-4 rounded-xl bg-[#0e121b] border border-gray-800">
            <span className="text-2xl font-black font-cyber text-red-400">ABAC</span>
            <span className="text-xs text-gray-300 font-bold block mt-1">Hardened Security</span>
            <p className="text-[10px] text-gray-500 mt-1">Zero orphaned writes or spoofed IDs</p>
          </div>
        </div>
      ),
      speakerNotes: 'Slide 13: Quantitative results, latency measurements, and code quality benchmarks.',
    },
    {
      id: 14,
      category: 'ROADMAP & CONCLUSION',
      title: 'Future Scope & Summary',
      subtitle: 'Expanding from hackathon directory to full lifecycle tournament engine',
      content: (
        <div className="space-y-4 text-xs sm:text-sm text-gray-300">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3 rounded-xl bg-gray-900/60 border border-gray-800">
              <strong className="text-red-400 font-cyber block">AI Teammate Matcher:</strong>
              <p className="text-xs text-gray-400">Match hackers based on complementary GitHub tech stacks, timezone, and project interests.</p>
            </div>
            <div className="p-3 rounded-xl bg-gray-900/60 border border-gray-800">
              <strong className="text-red-400 font-cyber block">Automated Submission Portal:</strong>
              <p className="text-xs text-gray-400">Integrated GitHub repo validator, automated unit-test runner, and live judging scoreboard.</p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-red-950/30 border border-red-500/40 text-center space-y-1">
            <h4 className="font-cyber font-bold text-white text-base">CONCLUSION</h4>
            <p className="text-xs text-gray-300 max-w-xl mx-auto">
              HackMatrix successfully delivers a production-grade, aesthetically distinctive hackathon hub combining modern cloud persistence, zero-trust security, and real-time synchronization.
            </p>
          </div>
        </div>
      ),
      speakerNotes: 'Slide 14: Conclusion summarizing deliverables and outlining roadmap.',
    },
  ];

  const current = slides[currentSlide];

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/95 backdrop-blur-xl flex flex-col animate-in fade-in">
      
      {/* Top Deck Control Header */}
      <div className="h-16 px-4 sm:px-6 border-b border-red-500/30 bg-[#090b10] flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-red-950/80 border border-red-500/50 flex items-center justify-center text-red-400">
            <Presentation className="w-4 h-4" />
          </div>
          <div>
            <span className="font-cyber font-bold text-sm sm:text-base text-white">
              HACKMATRIX ARCHITECTURE & PROJECT DECK
            </span>
            <span className="text-[11px] text-gray-400 font-mono-code hidden sm:inline ml-2">
              (14 Slides Comprehensive Breakdown)
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Download Full 15-Page File */}
          <a
            href="/HackMatrix_Complete_Project_Presentation.html"
            download="HackMatrix_Complete_Project_Presentation.html"
            title="Download Complete 15-Page File"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-white border border-red-400 text-xs font-mono-code transition-colors cursor-pointer shadow-md"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="font-semibold">Download PPT File (.html)</span>
          </a>

          {/* Download Markdown */}
          <a
            href="/HACKMATRIX_PROJECT_DOCUMENTATION_AND_PPT.md"
            download="HACKMATRIX_PROJECT_DOCUMENTATION_AND_PPT.md"
            title="Download Documentation Markdown File"
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gray-900 hover:bg-gray-800 text-gray-300 hover:text-white border border-gray-700 text-xs font-mono-code transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Markdown</span>
          </a>

          {/* Print / Export */}
          <button
            onClick={() => window.print()}
            title="Print or Save as PDF"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gray-900 hover:bg-gray-800 text-gray-300 hover:text-white border border-gray-700 text-xs font-mono-code transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Print / PDF</span>
          </button>

          {/* Close */}
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-red-950/40 hover:bg-red-950 text-red-400 hover:text-white border border-red-500/40 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Slide Canvas Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-8 flex items-center justify-center cyber-grid-bg">
        <div className="w-full max-w-4xl bg-[#0c101a] border border-red-500/40 rounded-2xl shadow-[0_0_60px_rgba(239,68,68,0.25)] p-6 sm:p-10 flex flex-col justify-between min-h-[460px] relative">
          
          {/* Slide Category & Counter */}
          <div className="flex items-center justify-between border-b border-gray-800 pb-3 mb-4">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-mono-code font-bold uppercase tracking-wider bg-red-950/80 text-red-400 border border-red-500/30">
                {current.category}
              </span>
            </div>
            <div className="text-xs font-mono-code text-gray-400">
              SLIDE <strong className="text-white font-cyber">{current.id}</strong> / {slides.length}
            </div>
          </div>

          {/* Slide Heading */}
          <div className="mb-6 space-y-1">
            <h2 className="text-2xl sm:text-3xl font-extrabold font-cyber text-white">
              {current.title}
            </h2>
            <p className="text-xs sm:text-sm text-gray-400">
              {current.subtitle}
            </p>
          </div>

          {/* Slide Main Content */}
          <div className="flex-1 flex flex-col justify-center">
            {current.content}
          </div>

          {/* Slide Footer with speaker notes preview */}
          <div className="mt-8 pt-4 border-t border-gray-800/80 flex items-center justify-between text-xs font-mono-code text-gray-500">
            <span className="truncate max-w-[80%] text-[11px]">
              Notes: {current.speakerNotes}
            </span>
            <span className="text-red-500 font-bold text-[11px]">HACKMATRIX</span>
          </div>

        </div>
      </div>

      {/* Bottom Navigation Dock */}
      <div className="h-16 px-4 sm:px-6 border-t border-red-500/30 bg-[#090b10] flex items-center justify-between shrink-0">
        <button
          onClick={() => setCurrentSlide((prev) => Math.max(prev - 1, 0))}
          disabled={currentSlide === 0}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gray-900 hover:bg-gray-800 disabled:opacity-30 disabled:cursor-not-allowed text-gray-200 border border-gray-800 text-xs font-semibold cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Previous</span>
        </button>

        {/* Slide Indicator Dots */}
        <div className="flex items-center gap-1.5 overflow-x-auto max-w-[50%] px-2">
          {slides.map((s, idx) => (
            <button
              key={s.id}
              onClick={() => setCurrentSlide(idx)}
              className={`w-2.5 h-2.5 rounded-full transition-all cursor-pointer ${
                idx === currentSlide
                  ? 'bg-red-500 w-6 shadow-[0_0_10px_rgba(239,68,68,0.8)]'
                  : 'bg-gray-700 hover:bg-gray-500'
              }`}
            />
          ))}
        </div>

        <button
          onClick={() => setCurrentSlide((prev) => Math.min(prev + 1, slides.length - 1))}
          disabled={currentSlide === slides.length - 1}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-30 disabled:cursor-not-allowed text-white text-xs font-semibold cursor-pointer shadow-md"
        >
          <span>Next</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

    </div>
  );
};
