import React from 'react';
import { AlertTriangle, Trash2, X } from 'lucide-react';
import { Hackathon } from '../types/hackathon';

interface DeleteConfirmModalProps {
  hackathon: Hackathon | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => Promise<void>;
  isDeleting: boolean;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  hackathon,
  isOpen,
  onClose,
  onConfirm,
  isDeleting,
}) => {
  if (!isOpen || !hackathon) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in">
      <div 
        className="relative w-full max-w-md bg-[#0e121b] border border-red-500/50 rounded-2xl shadow-[0_0_40px_rgba(239,68,68,0.3)] p-6 space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-red-950/80 border border-red-500/60 flex items-center justify-center text-red-400 shrink-0">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-cyber font-bold text-lg text-white">
              DELETE HACKATHON
            </h3>
            <p className="text-xs text-gray-400 font-mono-code">
              Permanent database deletion
            </p>
          </div>
        </div>

        <p className="text-sm text-gray-300">
          Are you sure you want to permanently delete{' '}
          <span className="font-semibold text-white">"{hackathon.title}"</span>?
          This action will immediately remove the listing from the public directory and cannot be undone.
        </p>

        <div className="pt-3 flex items-center justify-end gap-3 border-t border-gray-800">
          <button
            onClick={onClose}
            disabled={isDeleting}
            className="px-4 py-2 rounded-xl bg-gray-900 hover:bg-gray-800 text-gray-300 text-xs font-semibold"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            disabled={isDeleting}
            className="flex items-center gap-2 px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-semibold shadow-lg shadow-red-900/40"
          >
            <Trash2 className="w-4 h-4" />
            <span>{isDeleting ? 'Deleting...' : 'Confirm Delete'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
