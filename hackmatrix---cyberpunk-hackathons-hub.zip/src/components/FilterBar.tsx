import React from 'react';
import { Search, SlidersHorizontal, X, DollarSign, Globe2, MapPin, Sparkles } from 'lucide-react';
import { CategoryType, LocationType, FilterState } from '../types/hackathon';

interface FilterBarProps {
  filters: FilterState;
  onFilterChange: (filters: FilterState) => void;
  totalCount: number;
}

const CATEGORIES: CategoryType[] = [
  'All',
  'Cybersecurity',
  'AI & ML',
  'Web3 & Crypto',
  'Full-Stack',
  'Hardware & IoT',
  'Game Dev',
  'Open Innovation',
];

export const FilterBar: React.FC<FilterBarProps> = ({
  filters,
  onFilterChange,
  totalCount,
}) => {
  const handleCategorySelect = (category: CategoryType) => {
    onFilterChange({ ...filters, category });
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onFilterChange({ ...filters, searchQuery: e.target.value });
  };

  const clearSearch = () => {
    onFilterChange({ ...filters, searchQuery: '' });
  };

  const resetAllFilters = () => {
    onFilterChange({
      searchQuery: '',
      category: 'All',
      locationType: 'all',
      priceFilter: 'all',
      sortBy: 'upcoming',
    });
  };

  const isFiltered =
    filters.searchQuery !== '' ||
    filters.category !== 'All' ||
    filters.locationType !== 'all' ||
    filters.priceFilter !== 'all' ||
    filters.sortBy !== 'upcoming';

  return (
    <div className="space-y-4">
      {/* Search & Top Selectors Row */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={filters.searchQuery}
            onChange={handleSearchChange}
            placeholder="Search by hackathon title, tech stack, city, or organizer..."
            className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-[#0c101a] border border-gray-800 text-sm text-gray-100 placeholder-gray-500 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition-all font-sans"
          />
          {filters.searchQuery && (
            <button
              onClick={clearSearch}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-200"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Location Type Filter */}
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-[#0c101a] border border-gray-800 overflow-x-auto text-xs">
          {(['all', 'online', 'in-person', 'hybrid'] as LocationType[]).map((loc) => (
            <button
              key={loc}
              onClick={() => onFilterChange({ ...filters, locationType: loc })}
              className={`px-3 py-1.5 rounded-lg capitalize whitespace-nowrap transition-all ${
                filters.locationType === loc
                  ? 'bg-red-600/25 text-red-400 border border-red-500/40 font-medium'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              {loc === 'all' ? 'All Formats' : loc}
            </button>
          ))}
        </div>

        {/* Price Filter Pill */}
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-[#0c101a] border border-gray-800 text-xs">
          {(['all', 'free', 'paid'] as const).map((p) => (
            <button
              key={p}
              onClick={() => onFilterChange({ ...filters, priceFilter: p })}
              className={`px-3 py-1.5 rounded-lg capitalize whitespace-nowrap transition-all ${
                filters.priceFilter === p
                  ? 'bg-red-600/25 text-red-400 border border-red-500/40 font-medium'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              {p === 'all' ? 'All Prices' : p === 'free' ? 'Free Only' : 'Paid'}
            </button>
          ))}
        </div>

        {/* Sort Select */}
        <select
          value={filters.sortBy}
          onChange={(e) =>
            onFilterChange({
              ...filters,
              sortBy: e.target.value as FilterState['sortBy'],
            })
          }
          aria-label="Sort hackathons"
          className="px-3 py-2.5 rounded-xl bg-[#0c101a] border border-gray-800 text-xs text-gray-300 focus:outline-none focus:border-red-500 cursor-pointer font-mono-code"
        >
          <option value="upcoming">Sort: Starting Soon</option>
          <option value="prize">Sort: Highest Prize</option>
          <option value="popular">Sort: Most Participants</option>
          <option value="newest">Sort: Newly Listed</option>
        </select>
      </div>

      {/* Category Pills horizontal scroll */}
      <div className="flex items-center justify-between gap-4 pt-1">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {CATEGORIES.map((cat) => {
            const isSelected = filters.category === cat;
            return (
              <button
                key={cat}
                onClick={() => handleCategorySelect(cat)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-mono-code whitespace-nowrap transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-red-600 text-white shadow-[0_0_15px_rgba(239,68,68,0.4)] border border-red-400 font-semibold'
                    : 'bg-[#0e121b] text-gray-400 hover:text-gray-200 border border-gray-800 hover:border-gray-700'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>

        {/* Counter and Reset */}
        <div className="flex items-center gap-3 shrink-0 text-xs text-gray-400 font-mono-code">
          <span>
            <strong className="text-white font-cyber">{totalCount}</strong> events found
          </span>
          {isFiltered && (
            <button
              onClick={resetAllFilters}
              className="text-red-400 hover:text-red-300 underline text-xs cursor-pointer"
            >
              Reset
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
