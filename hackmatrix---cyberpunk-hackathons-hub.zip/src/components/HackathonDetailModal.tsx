import React, { useState, useEffect } from 'react';
import { 
  X, 
  Calendar, 
  MapPin, 
  Trophy, 
  Users, 
  Globe, 
  DollarSign, 
  ExternalLink, 
  Share2, 
  Check, 
  Edit3, 
  Trash2, 
  Clock, 
  ShieldCheck, 
  Sparkles,
  UserCheck,
  Tag
} from 'lucide-react';
import { Hackathon, HackathonRegistration } from '../types/hackathon';
import { useAuth } from '../context/AuthContext';
import { registerForHackathon, unregisterFromHackathon } from '../services/hackathonService';

interface HackathonDetailModalProps {
  hackathon: Hackathon | null;
  onClose: () => void;
  onEdit: (hackathon: Hackathon) => void;
  onDelete: (hackathon: Hackathon) => void;
  userRegistration?: HackathonRegistration | null;
}

export const HackathonDetailModal: React.FC<HackathonDetailModalProps> = ({
  hackathon,
  onClose,
  onEdit,
  onDelete,
  userRegistration,
}) => {
  const { currentUser, signInWithGoogle } = useAuth();
  const [activeTab, setActiveTab] = useState<'overview' | 'prizes' | 'rules'>('overview');
  const [copied, setCopied] = useState(false);

  // Registration form state
  const [showRegForm, setShowRegForm] = useState(false);
  const [teamName, setTeamName] = useState('');
  const [discordHandle, setDiscordHandle] = useState('');
  const [experienceLevel, setExperienceLevel] = useState('Intermediate');
  const [isSubmittingReg, setIsSubmittingReg] = useState(false);
  const [regError, setRegError] = useState<string | null>(null);

  // Countdown calculations
  const [timeLeft, setTimeLeft] = useState<{ days: number; hours: number; minutes: number; seconds: number }>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    if (!hackathon) return;

    const calculateTime = () => {
      const target = new Date(hackathon.startDate).getTime();
      const now = new Date().getTime();
      const difference = target - now;

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60),
        });
      } else {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      }
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, [hackathon]);

  if (!hackathon) return null;

  const isOwner = currentUser && currentUser.uid === hackathon.organizerId;
  const isRegistered = !!userRegistration;

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      await signInWithGoogle();
      return;
    }

    setIsSubmittingReg(true);
    setRegError(null);

    try {
      await registerForHackathon(hackathon, {
        userId: currentUser.uid,
        userEmail: currentUser.email || 'user@hackmatrix.dev',
        userName: currentUser.displayName || currentUser.email?.split('@')[0] || 'Anonymous Hacker',
        teamName: teamName.trim() || 'Solo Hacker',
        discordHandle: discordHandle.trim(),
        experienceLevel,
      });
      setShowRegForm(false);
    } catch (err: any) {
      setRegError(err.message || 'Failed to complete registration.');
    } finally {
      setIsSubmittingReg(false);
    }
  };

  const handleUnregister = async () => {
    if (!userRegistration) return;
    if (confirm('Are you sure you want to cancel your registration for this hackathon?')) {
      try {
        await unregisterFromHackathon(userRegistration.id, hackathon.id);
      } catch (err) {
        console.error('Failed to unregister:', err);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 lg:p-6 animate-in fade-in">
      <div 
        className="relative w-full max-w-4xl bg-[#0c101a] border border-red-500/40 rounded-2xl shadow-[0_0_50px_rgba(239,68,68,0.25)] overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-black/70 hover:bg-black text-gray-400 hover:text-white border border-gray-700 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Hero Banner Header */}
        <div className="relative h-60 sm:h-72 w-full bg-gray-950 overflow-hidden shrink-0">
          <img
            src={hackathon.bannerUrl || '/assets/aistudio/hackathon_98a10567.jpg'}
            alt={hackathon.title}
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0c101a] via-[#0c101a]/60 to-transparent" />

          {/* Badges on Banner */}
          <div className="absolute top-4 left-4 flex items-center gap-2 flex-wrap">
            <span className="px-3 py-1 rounded-md text-xs font-mono-code font-bold uppercase bg-red-600 text-white shadow-md border border-red-400">
              {hackathon.category}
            </span>
            <span className="px-2.5 py-1 rounded-md text-xs font-mono-code uppercase bg-black/70 text-gray-200 border border-gray-700 backdrop-blur-md">
              {hackathon.locationType}
            </span>
            {hackathon.price === 0 ? (
              <span className="px-2.5 py-1 rounded-md text-xs font-mono-code font-bold uppercase bg-emerald-950/90 text-emerald-400 border border-emerald-500/50">
                FREE ENTRY
              </span>
            ) : (
              <span className="px-2.5 py-1 rounded-md text-xs font-mono-code font-bold bg-red-950/90 text-red-400 border border-red-500/50">
                ${hackathon.price} REGISTRATION
              </span>
            )}
          </div>

          {/* Live countdown timer bar */}
          <div className="absolute bottom-4 left-4 right-4 flex flex-wrap items-end justify-between gap-4">
            <div>
              <div className="text-[11px] font-mono-code text-gray-400 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-red-400" />
                <span>Starts in:</span>
              </div>
              <div className="flex items-center gap-2 font-mono-code text-white">
                <div className="px-2.5 py-1 rounded-lg bg-black/80 border border-red-500/40 text-center min-w-[50px]">
                  <span className="text-lg font-bold text-red-400">{timeLeft.days}</span>
                  <span className="text-[9px] block text-gray-400">DAYS</span>
                </div>
                <span className="text-red-500 font-bold">:</span>
                <div className="px-2.5 py-1 rounded-lg bg-black/80 border border-red-500/40 text-center min-w-[50px]">
                  <span className="text-lg font-bold text-red-400">{timeLeft.hours}</span>
                  <span className="text-[9px] block text-gray-400">HOURS</span>
                </div>
                <span className="text-red-500 font-bold">:</span>
                <div className="px-2.5 py-1 rounded-lg bg-black/80 border border-red-500/40 text-center min-w-[50px]">
                  <span className="text-lg font-bold text-red-400">{timeLeft.minutes}</span>
                  <span className="text-[9px] block text-gray-400">MINS</span>
                </div>
                <span className="text-red-500 font-bold">:</span>
                <div className="px-2.5 py-1 rounded-lg bg-black/80 border border-red-500/40 text-center min-w-[50px]">
                  <span className="text-lg font-bold text-red-400">{timeLeft.seconds}</span>
                  <span className="text-[9px] block text-gray-400">SECS</span>
                </div>
              </div>
            </div>

            {/* Quick action: Share */}
            <button
              onClick={handleShare}
              className="px-3 py-1.5 rounded-lg bg-black/70 hover:bg-black text-gray-300 hover:text-white border border-gray-700 text-xs font-mono-code flex items-center gap-1.5 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
              <span>{copied ? 'Link Copied' : 'Share'}</span>
            </button>
          </div>
        </div>

        {/* Scrollable Body Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6">
          
          {/* Header titles & quick action row */}
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
            <div className="space-y-1.5 max-w-2xl">
              <h2 className="text-2xl sm:text-3xl font-extrabold font-cyber text-white leading-tight">
                {hackathon.title}
              </h2>
              <p className="text-sm sm:text-base text-gray-300 font-normal">
                {hackathon.tagline}
              </p>
            </div>

            {/* Primary Action Button (Register or Owner controls) */}
            <div className="flex flex-wrap items-center gap-2 shrink-0">
              {isOwner && (
                <>
                  <button
                    onClick={() => {
                      onClose();
                      onEdit(hackathon);
                    }}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gray-900 hover:bg-gray-800 text-gray-200 border border-gray-700 text-xs font-semibold cursor-pointer"
                  >
                    <Edit3 className="w-4 h-4 text-amber-400" />
                    <span>Edit Event</span>
                  </button>
                  <button
                    onClick={() => {
                      onClose();
                      onDelete(hackathon);
                    }}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-red-950/40 hover:bg-red-950 text-red-400 border border-red-500/40 text-xs font-semibold cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Delete</span>
                  </button>
                </>
              )}

              {/* Registration status / button */}
              {isRegistered ? (
                <div className="flex items-center gap-2">
                  <div className="px-4 py-2 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-400 text-xs font-mono-code font-bold flex items-center gap-2">
                    <UserCheck className="w-4 h-4" />
                    <span>REGISTERED ({userRegistration?.teamName || 'Solo'})</span>
                  </div>
                  <button
                    onClick={handleUnregister}
                    className="px-3 py-2 rounded-xl bg-gray-900 hover:bg-red-950/40 text-gray-400 hover:text-red-400 border border-gray-800 text-xs transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => {
                    if (!currentUser) {
                      signInWithGoogle();
                    } else {
                      setShowRegForm(!showRegForm);
                    }
                  }}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-semibold text-sm shadow-[0_0_20px_rgba(239,68,68,0.4)] transition-all cursor-pointer border border-red-400/40"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{currentUser ? 'Register for Hackathon' : 'Sign in to Register'}</span>
                </button>
              )}
            </div>
          </div>

          {/* Registration Drawer Form */}
          {showRegForm && !isRegistered && (
            <form 
              onSubmit={handleRegister}
              className="p-4 sm:p-5 rounded-xl bg-[#111724] border border-red-500/30 space-y-4 animate-in slide-in-from-top-3"
            >
              <div className="flex items-center justify-between border-b border-gray-800 pb-2">
                <div className="flex items-center gap-2 text-sm font-cyber font-bold text-white">
                  <Sparkles className="w-4 h-4 text-red-400" />
                  <span>CONFIRM PARTICIPANT REGISTRATION</span>
                </div>
                <button
                  type="button"
                  onClick={() => setShowRegForm(false)}
                  className="text-gray-400 hover:text-gray-200 text-xs"
                >
                  Cancel
                </button>
              </div>

              {regError && (
                <p className="text-xs text-red-400 bg-red-950/40 p-2.5 rounded-lg border border-red-500/30">
                  {regError}
                </p>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block text-gray-300 mb-1 font-mono-code">
                    Team Name (or Solo)
                  </label>
                  <input
                    type="text"
                    value={teamName}
                    onChange={(e) => setTeamName(e.target.value)}
                    placeholder="e.g. CyberVanguard or Solo Hacker"
                    className="w-full px-3 py-2 rounded-lg bg-gray-900 border border-gray-700 text-white focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block text-gray-300 mb-1 font-mono-code">
                    Discord / Handle (optional)
                  </label>
                  <input
                    type="text"
                    value={discordHandle}
                    onChange={(e) => setDiscordHandle(e.target.value)}
                    placeholder="e.g. @matrix_builder"
                    className="w-full px-3 py-2 rounded-lg bg-gray-900 border border-gray-700 text-white focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block text-gray-300 mb-1 font-mono-code">
                    Hacking Experience
                  </label>
                  <select
                    value={experienceLevel}
                    onChange={(e) => setExperienceLevel(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-gray-900 border border-gray-700 text-white focus:outline-none focus:border-red-500"
                  >
                    <option value="Beginner">First Hackathon / Beginner</option>
                    <option value="Intermediate">Intermediate (1-3 Hackathons)</option>
                    <option value="Veteran">Veteran / Senior Engineer</option>
                  </select>
                </div>

                <div className="flex flex-col justify-end">
                  <button
                    type="submit"
                    disabled={isSubmittingReg}
                    className="w-full py-2.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-semibold text-xs shadow-md cursor-pointer transition-colors"
                  >
                    {isSubmittingReg ? 'Securing Spot...' : 'Confirm Registration (Free / Instant)'}
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* Quick Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 rounded-xl bg-gray-900/60 border border-gray-800">
              <div className="flex items-center gap-1.5 text-xs text-gray-400 font-mono-code mb-1">
                <Trophy className="w-4 h-4 text-amber-400" />
                <span>Prize Pool</span>
              </div>
              <p className="font-cyber font-bold text-lg text-white">
                {hackathon.prizePool || 'TBA'}
              </p>
            </div>

            <div className="p-3 rounded-xl bg-gray-900/60 border border-gray-800">
              <div className="flex items-center gap-1.5 text-xs text-gray-400 font-mono-code mb-1">
                <DollarSign className="w-4 h-4 text-emerald-400" />
                <span>Entry Fee</span>
              </div>
              <p className="font-cyber font-bold text-lg text-emerald-400">
                {hackathon.price === 0 ? 'FREE' : `$${hackathon.price}`}
              </p>
            </div>

            <div className="p-3 rounded-xl bg-gray-900/60 border border-gray-800">
              <div className="flex items-center gap-1.5 text-xs text-gray-400 font-mono-code mb-1">
                <Calendar className="w-4 h-4 text-red-400" />
                <span>Dates</span>
              </div>
              <p className="font-mono-code text-xs font-semibold text-white truncate">
                {hackathon.startDate} → {hackathon.endDate}
              </p>
            </div>

            <div className="p-3 rounded-xl bg-gray-900/60 border border-gray-800">
              <div className="flex items-center gap-1.5 text-xs text-gray-400 font-mono-code mb-1">
                <Users className="w-4 h-4 text-cyan-400" />
                <span>Hackers</span>
              </div>
              <p className="font-cyber font-bold text-lg text-white">
                {hackathon.registeredCount || 0} Registered
              </p>
            </div>
          </div>

          {/* Location row */}
          <div className="flex items-center gap-2 p-3 rounded-xl bg-[#111724] border border-gray-800 text-xs text-gray-300 font-mono-code">
            <MapPin className="w-4 h-4 text-red-400 shrink-0" />
            <span className="text-gray-400">Venue / Location:</span>
            <span className="font-semibold text-white">{hackathon.location}</span>
            {hackathon.websiteUrl && (
              <a
                href={hackathon.websiteUrl}
                target="_blank"
                rel="noreferrer"
                className="ml-auto text-red-400 hover:text-red-300 flex items-center gap-1"
              >
                <span>Official Link</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
          </div>

          {/* Navigation Tabs */}
          <div className="border-b border-gray-800 flex items-center gap-2">
            {(['overview', 'prizes', 'rules'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`pb-2.5 px-3 text-xs sm:text-sm font-medium capitalize border-b-2 transition-all cursor-pointer ${
                  activeTab === tab
                    ? 'border-red-500 text-red-400 font-semibold'
                    : 'border-transparent text-gray-400 hover:text-gray-200'
                }`}
              >
                {tab === 'overview' ? 'Overview & Tracks' : tab === 'prizes' ? 'Prizes & Rewards' : 'Rules & Format'}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="space-y-4 text-sm text-gray-300 font-sans leading-relaxed">
            {activeTab === 'overview' && (
              <div className="space-y-4">
                <div className="whitespace-pre-line text-gray-300">
                  {hackathon.description}
                </div>

                {hackathon.tags && hackathon.tags.length > 0 && (
                  <div className="pt-2">
                    <span className="text-xs font-mono-code text-gray-400 block mb-2">
                      TAGS & FOCUS AREAS:
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {hackathon.tags.map((tag, i) => (
                        <span
                          key={i}
                          className="px-2.5 py-1 rounded-lg bg-gray-900 border border-gray-800 text-xs font-mono-code text-gray-300"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'prizes' && (
              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-gradient-to-r from-amber-950/30 to-red-950/20 border border-amber-500/30 space-y-2">
                  <div className="flex items-center gap-2 text-amber-400 font-cyber font-bold text-base">
                    <Trophy className="w-5 h-5" />
                    <span>TOTAL PRIZE POOL: {hackathon.prizePool || '$50,000 USD'}</span>
                  </div>
                  <p className="text-xs text-gray-400 font-mono-code">
                    Prizes awarded in cash grants, GPU cloud compute credits, and venture incubation fast-tracks.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-3.5 rounded-xl bg-gray-900/60 border border-gray-800">
                    <span className="text-xs font-mono-code text-amber-400 font-bold block mb-1">
                      🥇 1st Place (Grand Prize)
                    </span>
                    <p className="text-sm font-semibold text-white">50% of Pool</p>
                    <p className="text-xs text-gray-400 mt-1">Direct grant + Mentor access</p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-gray-900/60 border border-gray-800">
                    <span className="text-xs font-mono-code text-slate-300 font-bold block mb-1">
                      🥈 2nd Place (Runner-up)
                    </span>
                    <p className="text-sm font-semibold text-white">30% of Pool</p>
                    <p className="text-xs text-gray-400 mt-1">Cloud credits + API tokens</p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-gray-900/60 border border-gray-800">
                    <span className="text-xs font-mono-code text-amber-600 font-bold block mb-1">
                      🥉 3rd Place (Special Track)
                    </span>
                    <p className="text-sm font-semibold text-white">20% of Pool</p>
                    <p className="text-xs text-gray-400 mt-1">Hardware kits & licenses</p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'rules' && (
              <div className="space-y-3">
                <div className="p-4 rounded-xl bg-gray-900/50 border border-gray-800 space-y-2">
                  <h4 className="font-cyber font-bold text-sm text-white">HACKATHON GUIDELINES</h4>
                  <p className="text-xs text-gray-300">
                    {hackathon.rules || 'Teams of 1-4 hackers allowed. All repositories must be initialized during the official sprint dates. Code must be verifiable and run on local or cloud containers.'}
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-gray-900/50 border border-gray-800 space-y-2">
                  <h4 className="font-cyber font-bold text-sm text-white">CODE OF CONDUCT</h4>
                  <p className="text-xs text-gray-300">
                    HackMatrix enforces an inclusive, high-integrity environment. Plagiarism, harassment, or malicious attacks against fellow participants will lead to immediate disqualification.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Organizer Card info */}
          <div className="pt-4 border-t border-gray-800/80 flex items-center justify-between">
            <div className="flex items-center gap-3">
              {hackathon.organizerAvatar ? (
                <img
                  src={hackathon.organizerAvatar}
                  alt={hackathon.organizerName}
                  className="w-10 h-10 rounded-full object-cover border border-red-500/40"
                />
              ) : (
                <div className="w-10 h-10 rounded-full bg-red-950/80 border border-red-500/40 flex items-center justify-center text-red-400 font-mono-code text-sm font-bold">
                  {hackathon.organizerName.slice(0, 2).toUpperCase()}
                </div>
              )}
              <div>
                <span className="text-[10px] uppercase font-mono-code text-gray-400 block">
                  ORGANIZED BY
                </span>
                <span className="text-sm font-semibold text-white">
                  {hackathon.organizerName}
                </span>
              </div>
            </div>

            <div className="text-right text-xs font-mono-code text-gray-400">
              <span>Contact: </span>
              <a href={`mailto:${hackathon.organizerEmail}`} className="text-red-400 hover:underline">
                {hackathon.organizerEmail}
              </a>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
