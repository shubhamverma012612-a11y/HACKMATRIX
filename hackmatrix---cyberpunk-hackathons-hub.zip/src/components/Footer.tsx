import React from 'react';
import { Terminal, Shield, Cpu, Flame, Heart } from 'lucide-react';

export const Footer: React.FC<{ onOpenPresentationModal?: () => void }> = ({ onOpenPresentationModal }) => {
  return (
    <footer className="border-t border-red-500/20 bg-[#07090e] py-10 text-xs font-mono-code text-gray-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-red-950/60 border border-red-500/40 flex items-center justify-center text-red-500">
              <Terminal className="w-4 h-4 text-red-400" />
            </div>
            <div>
              <span className="font-cyber font-bold text-base text-white">
                HACK<span className="text-red-500">MATRIX</span>
              </span>
              <p className="text-[11px] text-gray-500">
                Decentralized Hackathon Command Protocol
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 sm:gap-6 text-gray-400 flex-wrap">
            <span className="flex items-center gap-1.5 text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              FIRESTORE REALTIME SYNC
            </span>
            <span className="hidden sm:inline text-gray-600">|</span>
            {onOpenPresentationModal && (
              <button
                onClick={onOpenPresentationModal}
                className="text-red-400 hover:text-red-300 underline font-semibold cursor-pointer"
              >
                📊 Open Architecture PPT
              </button>
            )}
            <span className="hidden sm:inline text-gray-600">|</span>
            <a
              href="/HackMatrix_Complete_Project_Report_35_Pages.html"
              target="_blank"
              rel="noreferrer"
              className="text-red-400 hover:text-red-300 underline font-semibold"
            >
              📄 Academic Project Report (35-40 Pages)
            </a>
            <span className="hidden sm:inline text-gray-600">|</span>
            <span className="text-gray-400">ZERO DOWNTIME</span>
          </div>
        </div>

        <div className="pt-6 border-t border-gray-900 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-gray-500">
          <p>© {new Date().getFullYear()} HackMatrix. Built for elite engineers, researchers, and builders.</p>
          <p className="flex items-center gap-1">
            Engineered with <Flame className="w-3.5 h-3.5 text-red-500" /> on Google Cloud
          </p>
        </div>
      </div>
    </footer>
  );
};
