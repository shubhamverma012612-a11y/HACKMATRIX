import React, { useState, useEffect } from 'react';
import { 
  X, 
  Upload, 
  Image as ImageIcon, 
  DollarSign, 
  MapPin, 
  Calendar, 
  Trophy, 
  Tag, 
  Sparkles,
  Link2,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { Hackathon } from '../types/hackathon';
import { useAuth } from '../context/AuthContext';
import { PRESET_BANNERS, createHackathon, updateHackathon } from '../services/hackathonService';

interface CreateEditHackathonModalProps {
  isOpen: boolean;
  onClose: () => void;
  editTarget: Hackathon | null;
}

export const CreateEditHackathonModal: React.FC<CreateEditHackathonModalProps> = ({
  isOpen,
  onClose,
  editTarget,
}) => {
  const { currentUser } = useAuth();
  const isEditing = !!editTarget;

  // Form State
  const [title, setTitle] = useState('');
  const [tagline, setTagline] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Cybersecurity');
  const [locationType, setLocationType] = useState<'online' | 'in-person' | 'hybrid'>('online');
  const [location, setLocation] = useState('Global Virtual Network');
  const [price, setPrice] = useState<number>(0);
  const [prizePool, setPrizePool] = useState('$50,000 USD');
  const [bannerUrl, setBannerUrl] = useState('/assets/aistudio/hackathon_98a10567.jpg');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [tagsInput, setTagsInput] = useState('AI, Cybersecurity, Hackathon');
  const [rules, setRules] = useState('');

  // UI status
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Populate fields if editing
  useEffect(() => {
    if (editTarget) {
      setTitle(editTarget.title);
      setTagline(editTarget.tagline || '');
      setDescription(editTarget.description);
      setCategory(editTarget.category);
      setLocationType(editTarget.locationType);
      setLocation(editTarget.location);
      setPrice(editTarget.price || 0);
      setPrizePool(editTarget.prizePool || '$50,000 USD');
      setBannerUrl(editTarget.bannerUrl || '/assets/aistudio/hackathon_98a10567.jpg');
      setStartDate(editTarget.startDate);
      setEndDate(editTarget.endDate);
      setWebsiteUrl(editTarget.websiteUrl || '');
      setTagsInput(editTarget.tags ? editTarget.tags.join(', ') : '');
      setRules(editTarget.rules || '');
    } else {
      // Default dates for new hackathons: starting next week, ending 3 days later
      const nextWeek = new Date();
      nextWeek.setDate(nextWeek.getDate() + 7);
      const ends = new Date(nextWeek);
      ends.setDate(ends.getDate() + 3);

      setTitle('');
      setTagline('');
      setDescription('');
      setCategory('Cybersecurity');
      setLocationType('online');
      setLocation('Global Virtual / Discord');
      setPrice(0);
      setPrizePool('$50,000 USD');
      setBannerUrl('/assets/aistudio/hackathon_98a10567.jpg');
      setStartDate(nextWeek.toISOString().split('T')[0]);
      setEndDate(ends.toISOString().split('T')[0]);
      setWebsiteUrl('');
      setTagsInput('Cybersecurity, AI, Zero Trust');
      setRules('Teams of 1-4. All work completed during official sprint. Open source projects encouraged.');
    }
    setErrorMsg(null);
  }, [editTarget, isOpen]);

  if (!isOpen) return null;

  // Handle local image file upload and convert to Data URL
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        setErrorMsg('Image size must be under 2MB for fast loading.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setBannerUrl(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setErrorMsg('You must be signed in to publish a hackathon.');
      return;
    }

    if (!title.trim()) {
      setErrorMsg('Please enter a hackathon title.');
      return;
    }

    if (!description.trim()) {
      setErrorMsg('Please write a description for your hackathon.');
      return;
    }

    if (!startDate || !endDate) {
      setErrorMsg('Please specify both start and end dates.');
      return;
    }

    setSubmitting(true);
    setErrorMsg(null);

    const tagsArray = tagsInput
      .split(',')
      .map((t) => t.trim())
      .filter((t) => t.length > 0);

    try {
      if (isEditing && editTarget) {
        await updateHackathon(editTarget.id, {
          title: title.trim(),
          tagline: tagline.trim(),
          description: description.trim(),
          category,
          locationType,
          location: location.trim(),
          price: Number(price) || 0,
          prizePool: prizePool.trim(),
          bannerUrl,
          startDate,
          endDate,
          websiteUrl: websiteUrl.trim(),
          tags: tagsArray,
          rules: rules.trim(),
        });
      } else {
        await createHackathon({
          title: title.trim(),
          tagline: tagline.trim(),
          description: description.trim(),
          category,
          locationType,
          location: location.trim(),
          price: Number(price) || 0,
          prizePool: prizePool.trim(),
          bannerUrl,
          startDate,
          endDate,
          websiteUrl: websiteUrl.trim(),
          tags: tagsArray,
          rules: rules.trim(),
          organizerId: currentUser.uid,
          organizerName: currentUser.displayName || currentUser.email?.split('@')[0] || 'Organizer',
          organizerEmail: currentUser.email || 'organizer@hackmatrix.dev',
          organizerAvatar: currentUser.photoURL || undefined,
        });
      }
      onClose();
    } catch (err: any) {
      console.error('Save hackathon error:', err);
      setErrorMsg(err.message || 'Failed to save hackathon to Firestore.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 lg:p-6 animate-in fade-in">
      <div 
        className="relative w-full max-w-3xl bg-[#0c101a] border border-red-500/40 rounded-2xl shadow-[0_0_50px_rgba(239,68,68,0.25)] overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 bg-[#080b12] border-b border-red-500/30 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-950/80 border border-red-500/50 flex items-center justify-center text-red-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-cyber font-bold text-lg text-white">
                {isEditing ? 'EDIT HACKATHON PROTOCOL' : 'LAUNCH NEW HACKATHON'}
              </h2>
              <p className="text-[11px] text-gray-400 font-mono-code">
                Saved permanently in Firestore & broadcasted in real-time
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-gray-900 hover:bg-gray-800 text-gray-400 hover:text-white border border-gray-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Content */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 text-xs sm:text-sm">
          
          {errorMsg && (
            <div className="p-3.5 rounded-xl bg-red-950/40 border border-red-500/40 flex items-center gap-2.5 text-red-300 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Banner Image Selection */}
          <div className="space-y-3">
            <label className="block text-gray-200 font-mono-code font-semibold">
              BANNER IMAGE SELECTION (OR UPLOAD)
            </label>

            {/* Preview Banner */}
            <div className="relative aspect-[16/7] w-full rounded-xl overflow-hidden bg-gray-950 border border-red-500/30">
              <img
                src={bannerUrl}
                alt="Banner Preview"
                className="w-full h-full object-cover object-center"
              />
              <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-black/80 text-[10px] font-mono-code text-red-400 border border-red-500/30">
                ACTIVE PREVIEW
              </div>
            </div>

            {/* Quick Presets */}
            <div>
              <span className="text-[11px] font-mono-code text-gray-400 block mb-1.5">
                Quick Cyberpunk Presets (Includes Reference Battlestation):
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {PRESET_BANNERS.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setBannerUrl(preset.url)}
                    className={`p-2 rounded-lg text-left text-[11px] font-mono-code truncate border transition-all ${
                      bannerUrl === preset.url
                        ? 'bg-red-600/20 text-red-300 border-red-500 font-bold'
                        : 'bg-gray-900 text-gray-400 border-gray-800 hover:border-gray-700'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Custom URL or File Upload */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-[11px] text-gray-400 font-mono-code mb-1">
                  Or Paste Custom Image URL:
                </label>
                <div className="relative">
                  <Link2 className="w-4 h-4 text-gray-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="url"
                    value={bannerUrl}
                    onChange={(e) => setBannerUrl(e.target.value)}
                    placeholder="https://images.unsplash.com/..."
                    className="w-full pl-9 pr-3 py-2 rounded-lg bg-gray-900 border border-gray-800 text-white focus:outline-none focus:border-red-500 text-xs font-mono-code"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-gray-400 font-mono-code mb-1">
                  Or Upload Local Image:
                </label>
                <label className="flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-gray-900 border border-gray-800 hover:border-red-500/40 text-gray-300 hover:text-white cursor-pointer transition-colors text-xs font-mono-code">
                  <Upload className="w-3.5 h-3.5 text-red-400" />
                  <span>Choose file from device</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>
          </div>

          {/* Title & Tagline */}
          <div className="grid grid-cols-1 gap-4">
            <div>
              <label className="block text-gray-200 font-mono-code font-semibold mb-1">
                HACKATHON NAME / TITLE *
              </label>
              <input
                type="text"
                required
                maxLength={140}
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. CYBERSTORM 2026: Autonomous Security Sprint"
                className="w-full px-3.5 py-2.5 rounded-xl bg-gray-900 border border-gray-800 text-white focus:outline-none focus:border-red-500 text-sm font-sans"
              />
            </div>

            <div>
              <label className="block text-gray-200 font-mono-code font-semibold mb-1">
                PUNCHY TAGLINE
              </label>
              <input
                type="text"
                maxLength={240}
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                placeholder="e.g. Red-team vs autonomous agents in a 48-hour global challenge"
                className="w-full px-3.5 py-2 rounded-xl bg-gray-900 border border-gray-800 text-white focus:outline-none focus:border-red-500 text-xs font-sans"
              />
            </div>
          </div>

          {/* Category, Location Type, Price, Prize Pool */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Category */}
            <div>
              <label className="block text-gray-300 font-mono-code mb-1">
                CATEGORY
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-gray-900 border border-gray-800 text-white focus:outline-none focus:border-red-500 text-xs"
              >
                <option value="Cybersecurity">Cybersecurity</option>
                <option value="AI & ML">AI & Machine Learning</option>
                <option value="Web3 & Crypto">Web3 & Crypto</option>
                <option value="Full-Stack">Full-Stack & Cloud</option>
                <option value="Hardware & IoT">Hardware & IoT</option>
                <option value="Game Dev">Game Dev</option>
                <option value="Open Innovation">Open Innovation</option>
              </select>
            </div>

            {/* Location Type */}
            <div>
              <label className="block text-gray-300 font-mono-code mb-1">
                FORMAT
              </label>
              <select
                value={locationType}
                onChange={(e) => setLocationType(e.target.value as any)}
                className="w-full px-3 py-2 rounded-lg bg-gray-900 border border-gray-800 text-white focus:outline-none focus:border-red-500 text-xs"
              >
                <option value="online">Online / Virtual</option>
                <option value="in-person">In-Person Only</option>
                <option value="hybrid">Hybrid (Both)</option>
              </select>
            </div>

            {/* Registration Fee */}
            <div>
              <label className="block text-gray-300 font-mono-code mb-1">
                REGISTRATION FEE ($USD)
              </label>
              <div className="relative">
                <DollarSign className="w-3.5 h-3.5 text-gray-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={price}
                  onChange={(e) => setPrice(Math.max(0, parseFloat(e.target.value) || 0))}
                  placeholder="0 (Free)"
                  className="w-full pl-8 pr-3 py-2 rounded-lg bg-gray-900 border border-gray-800 text-white focus:outline-none focus:border-red-500 text-xs font-mono-code"
                />
              </div>
              <span className="text-[10px] text-gray-500 mt-0.5 block">0 = Free Hackathon</span>
            </div>

            {/* Prize Pool */}
            <div>
              <label className="block text-gray-300 font-mono-code mb-1">
                PRIZE POOL
              </label>
              <input
                type="text"
                value={prizePool}
                onChange={(e) => setPrizePool(e.target.value)}
                placeholder="e.g. $75,000 USD"
                className="w-full px-3 py-2 rounded-lg bg-gray-900 border border-gray-800 text-white focus:outline-none focus:border-red-500 text-xs font-mono-code"
              />
            </div>
          </div>

          {/* Location and Dates */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-gray-300 font-mono-code mb-1">
                VENUE / VENUE PLATFORM
              </label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g. Global Discord or San Francisco, CA"
                className="w-full px-3 py-2 rounded-lg bg-gray-900 border border-gray-800 text-white focus:outline-none focus:border-red-500 text-xs"
              />
            </div>

            <div>
              <label className="block text-gray-300 font-mono-code mb-1">
                START DATE *
              </label>
              <input
                type="date"
                required
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-gray-900 border border-gray-800 text-white focus:outline-none focus:border-red-500 text-xs font-mono-code"
              />
            </div>

            <div>
              <label className="block text-gray-300 font-mono-code mb-1">
                END DATE *
              </label>
              <input
                type="date"
                required
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-gray-900 border border-gray-800 text-white focus:outline-none focus:border-red-500 text-xs font-mono-code"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-gray-200 font-mono-code font-semibold mb-1">
              FULL DESCRIPTION & CHALLENGE DETAILS *
            </label>
            <textarea
              required
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Detail the tracks, challenge scope, deliverables, technologies, and schedule..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-gray-900 border border-gray-800 text-white focus:outline-none focus:border-red-500 text-xs sm:text-sm font-sans"
            />
          </div>

          {/* Tags & External Website */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-300 font-mono-code mb-1">
                TAGS (COMMA SEPARATED)
              </label>
              <input
                type="text"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                placeholder="Cybersecurity, AI, Zero Trust, Rust"
                className="w-full px-3 py-2 rounded-lg bg-gray-900 border border-gray-800 text-white focus:outline-none focus:border-red-500 text-xs font-mono-code"
              />
            </div>

            <div>
              <label className="block text-gray-300 font-mono-code mb-1">
                WEBSITE OR DISCORD LINK
              </label>
              <input
                type="url"
                value={websiteUrl}
                onChange={(e) => setWebsiteUrl(e.target.value)}
                placeholder="https://myhackathon.dev"
                className="w-full px-3 py-2 rounded-lg bg-gray-900 border border-gray-800 text-white focus:outline-none focus:border-red-500 text-xs font-mono-code"
              />
            </div>
          </div>

          {/* Rules */}
          <div>
            <label className="block text-gray-300 font-mono-code mb-1">
              SPECIAL RULES & SUBMISSION CRITERIA
            </label>
            <input
              type="text"
              value={rules}
              onChange={(e) => setRules(e.target.value)}
              placeholder="e.g. Teams of 1-4. Must be open-source repository."
              className="w-full px-3 py-2 rounded-lg bg-gray-900 border border-gray-800 text-white focus:outline-none focus:border-red-500 text-xs"
            />
          </div>

          {/* Submit Actions */}
          <div className="pt-4 border-t border-gray-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="px-4 py-2.5 rounded-xl bg-gray-900 hover:bg-gray-800 text-gray-300 hover:text-white border border-gray-700 text-xs font-semibold cursor-pointer transition-colors"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={submitting}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-semibold text-xs sm:text-sm shadow-[0_0_20px_rgba(239,68,68,0.4)] cursor-pointer transition-all border border-red-400/40"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{submitting ? 'Saving to Database...' : isEditing ? 'Save Changes' : 'Publish Hackathon'}</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
