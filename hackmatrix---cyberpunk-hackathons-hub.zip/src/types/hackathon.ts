export type CategoryType = 
  | 'All'
  | 'AI & ML'
  | 'Cybersecurity'
  | 'Web3 & Crypto'
  | 'Full-Stack'
  | 'Game Dev'
  | 'Hardware & IoT'
  | 'Open Innovation';

export type LocationType = 'all' | 'online' | 'in-person' | 'hybrid';

export interface Hackathon {
  id: string;
  title: string;
  tagline: string;
  description: string;
  category: string;
  locationType: 'online' | 'in-person' | 'hybrid';
  location: string;
  price: number;
  prizePool: string;
  bannerUrl: string;
  startDate: string;
  endDate: string;
  organizerId: string;
  organizerName: string;
  organizerEmail: string;
  organizerAvatar?: string;
  websiteUrl?: string;
  registeredCount: number;
  tags?: string[];
  rules?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface HackathonRegistration {
  id: string;
  hackathonId: string;
  hackathonTitle?: string;
  hackathonBanner?: string;
  hackathonStartDate?: string;
  userId: string;
  userEmail: string;
  userName: string;
  teamName?: string;
  discordHandle?: string;
  experienceLevel?: string;
  registeredAt: string;
}

export interface FilterState {
  searchQuery: string;
  category: CategoryType;
  locationType: LocationType;
  priceFilter: 'all' | 'free' | 'paid';
  sortBy: 'upcoming' | 'prize' | 'popular' | 'newest';
}
