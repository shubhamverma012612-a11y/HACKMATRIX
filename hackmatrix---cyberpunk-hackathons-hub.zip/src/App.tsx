import React, { useState, useEffect, useMemo } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { FilterBar } from './components/FilterBar';
import { HackathonCard } from './components/HackathonCard';
import { HackathonDetailModal } from './components/HackathonDetailModal';
import { CreateEditHackathonModal } from './components/CreateEditHackathonModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { PresentationModal } from './components/PresentationModal';
import { DashboardView } from './components/DashboardView';
import { Footer } from './components/Footer';
import { 
  Hackathon, 
  HackathonRegistration, 
  FilterState 
} from './types/hackathon';
import { 
  subscribeToHackathons, 
  subscribeToUserRegistrations, 
  seedInitialHackathonsIfEmpty,
  deleteHackathon
} from './services/hackathonService';
import { Flame, Loader2, PlusCircle, AlertCircle, Sparkles } from 'lucide-react';

function MainApp() {
  const { currentUser, authError, clearAuthError, signInWithGoogle } = useAuth();
  
  // Navigation & Modal States
  const [currentView, setCurrentView] = useState<'explore' | 'dashboard'>('explore');
  const [selectedHackathon, setSelectedHackathon] = useState<Hackathon | null>(null);
  const [isCreateEditOpen, setIsCreateEditOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<Hackathon | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Hackathon | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isPresentationOpen, setIsPresentationOpen] = useState(false);

  // Data States
  const [hackathons, setHackathons] = useState<Hackathon[]>([]);
  const [registrations, setRegistrations] = useState<HackathonRegistration[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filters State
  const [filters, setFilters] = useState<FilterState>({
    searchQuery: '',
    category: 'All',
    locationType: 'all',
    priceFilter: 'all',
    sortBy: 'upcoming',
  });

  // Subscribe to real-time hackathons
  useEffect(() => {
    const unsubscribe = subscribeToHackathons(
      (data) => {
        setHackathons(data);
        setIsLoading(false);
        // Seed sample hackathons if empty on first boot
        if (data.length === 0) {
          seedInitialHackathonsIfEmpty(0);
        }
      },
      (err) => {
        console.error('Subscription error:', err);
        setIsLoading(false);
      }
    );

    return () => unsubscribe();
  }, []);

  // Subscribe to current user's registrations
  useEffect(() => {
    if (!currentUser) {
      setRegistrations([]);
      return;
    }

    const unsubscribe = subscribeToUserRegistrations(
      currentUser.uid,
      (regs) => {
        setRegistrations(regs);
      },
      (err) => {
        console.warn('Registrations fetch note:', err);
      }
    );

    return () => unsubscribe();
  }, [currentUser]);

  // Keep selectedHackathon synced if updated in Firestore
  useEffect(() => {
    if (selectedHackathon) {
      const refreshed = hackathons.find((h) => h.id === selectedHackathon.id);
      if (refreshed) {
        setSelectedHackathon(refreshed);
      }
    }
  }, [hackathons]);

  // Filtered & Sorted Hackathons
  const filteredHackathons = useMemo(() => {
    return hackathons.filter((h) => {
      // Category filter
      if (filters.category !== 'All' && h.category !== filters.category) {
        return false;
      }

      // Location type filter
      if (filters.locationType !== 'all' && h.locationType !== filters.locationType) {
        return false;
      }

      // Price filter
      if (filters.priceFilter === 'free' && h.price > 0) {
        return false;
      }
      if (filters.priceFilter === 'paid' && h.price === 0) {
        return false;
      }

      // Search query (matches title, tagline, description, location, or tags)
      if (filters.searchQuery.trim()) {
        const query = filters.searchQuery.toLowerCase();
        const titleMatch = h.title.toLowerCase().includes(query);
        const taglineMatch = (h.tagline || '').toLowerCase().includes(query);
        const descMatch = (h.description || '').toLowerCase().includes(query);
        const locationMatch = (h.location || '').toLowerCase().includes(query);
        const tagsMatch = (h.tags || []).some((t) => t.toLowerCase().includes(query));
        const organizerMatch = (h.organizerName || '').toLowerCase().includes(query);

        if (!titleMatch && !taglineMatch && !descMatch && !locationMatch && !tagsMatch && !organizerMatch) {
          return false;
        }
      }

      return true;
    }).sort((a, b) => {
      if (filters.sortBy === 'upcoming') {
        return new Date(a.startDate).getTime() - new Date(b.startDate).getTime();
      }
      if (filters.sortBy === 'prize') {
        // extract digits
        const numA = parseInt(a.prizePool?.replace(/[^0-9]/g, '') || '0', 10);
        const numB = parseInt(b.prizePool?.replace(/[^0-9]/g, '') || '0', 10);
        return numB - numA;
      }
      if (filters.sortBy === 'popular') {
        return (b.registeredCount || 0) - (a.registeredCount || 0);
      }
      if (filters.sortBy === 'newest') {
        return new Date(b.createdAt || '').getTime() - new Date(a.createdAt || '').getTime();
      }
      return 0;
    });
  }, [hackathons, filters]);

  // User's hosted hackathons
  const myHostedHackathons = useMemo(() => {
    if (!currentUser) return [];
    return hackathons.filter((h) => h.organizerId === currentUser.uid);
  }, [hackathons, currentUser]);

  // Registration lookup helper
  const getRegistrationForHackathon = (hackathonId: string) => {
    return registrations.find((r) => r.hackathonId === hackathonId) || null;
  };

  // Handlers
  const handleOpenCreateModal = () => {
    if (!currentUser) {
      signInWithGoogle();
      return;
    }
    setEditTarget(null);
    setIsCreateEditOpen(true);
  };

  const handleEditHackathon = (hackathon: Hackathon) => {
    setEditTarget(hackathon);
    setIsCreateEditOpen(true);
  };

  const handleDeletePrompt = (hackathon: Hackathon) => {
    setDeleteTarget(hackathon);
  };

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await deleteHackathon(deleteTarget.id);
      if (selectedHackathon?.id === deleteTarget.id) {
        setSelectedHackathon(null);
      }
      setDeleteTarget(null);
    } catch (err) {
      console.error('Delete error:', err);
    } finally {
      setIsDeleting(false);
    }
  };

  const scrollToExplore = () => {
    setCurrentView('explore');
    const el = document.getElementById('explore-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#07090e] text-[#e2e8f0] flex flex-col font-sans selection:bg-red-500 selection:text-white">
      
      {/* Top Notification / Auth Error Banner */}
      {authError && (
        <div className="bg-red-950/90 border-b border-red-500 text-red-200 px-4 py-2.5 text-xs font-mono-code flex items-center justify-between z-50">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>Authentication Notice: {authError}</span>
          </div>
          <button onClick={clearAuthError} className="text-white hover:underline">
            Dismiss
          </button>
        </div>
      )}

      {/* Main Navbar */}
      <Navbar
        onOpenCreateModal={handleOpenCreateModal}
        onOpenPresentationModal={() => setIsPresentationOpen(true)}
        currentView={currentView}
        setCurrentView={setCurrentView}
      />

      {/* Main Page Content */}
      <main className="flex-1">
        {currentView === 'explore' ? (
          <div>
            {/* Cyberpunk Hero Section featuring Reference Image */}
            <HeroSection
              onExploreClick={scrollToExplore}
              onHostClick={handleOpenCreateModal}
              hackathonsCount={hackathons.length}
            />

            {/* Hackathons Directory Section */}
            <section id="explore-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
              
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-gray-800 pb-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse inline-block" />
                    <span className="text-xs font-mono-code text-red-400 font-semibold uppercase tracking-wider">
                      LIVE DIRECTORY
                    </span>
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-extrabold font-cyber text-white">
                    EXPLORE HACKATHONS
                  </h2>
                </div>

                <button
                  onClick={handleOpenCreateModal}
                  className="self-start md:self-auto flex items-center gap-2 px-4 py-2 rounded-xl bg-[#0f1422] hover:bg-[#161d2f] text-gray-200 border border-red-500/30 hover:border-red-500/60 text-xs font-medium transition-all"
                >
                  <PlusCircle className="w-4 h-4 text-red-400" />
                  <span>Host a Hackathon</span>
                </button>
              </div>

              {/* Filters and Search Bar */}
              <FilterBar
                filters={filters}
                onFilterChange={setFilters}
                totalCount={filteredHackathons.length}
              />

              {/* Loading State */}
              {isLoading ? (
                <div className="py-20 text-center space-y-3">
                  <Loader2 className="w-8 h-8 text-red-500 animate-spin mx-auto" />
                  <p className="text-xs font-mono-code text-gray-400">
                    Connecting to Firestore real-time stream...
                  </p>
                </div>
              ) : filteredHackathons.length === 0 ? (
                /* Empty Filter State */
                <div className="py-16 text-center rounded-2xl bg-[#0c101a] border border-gray-800 space-y-4">
                  <div className="w-12 h-12 rounded-full bg-red-950/40 border border-red-500/30 flex items-center justify-center text-red-400 mx-auto">
                    <AlertCircle className="w-6 h-6" />
                  </div>
                  <h3 className="font-cyber font-bold text-lg text-white">
                    NO HACKATHONS MATCH YOUR FILTER
                  </h3>
                  <p className="text-xs text-gray-400 max-w-md mx-auto">
                    Try adjusting your search query, selecting "All Formats", or resetting category filters to discover active events.
                  </p>
                  <button
                    onClick={() =>
                      setFilters({
                        searchQuery: '',
                        category: 'All',
                        locationType: 'all',
                        priceFilter: 'all',
                        sortBy: 'upcoming',
                      })
                    }
                    className="px-4 py-2 rounded-xl bg-gray-900 hover:bg-gray-800 text-xs text-red-400 border border-gray-700"
                  >
                    Reset All Filters
                  </button>
                </div>
              ) : (
                /* Hackathons Grid */
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
                  {filteredHackathons.map((hackathon) => (
                    <HackathonCard
                      key={hackathon.id}
                      hackathon={hackathon}
                      onSelect={(h) => setSelectedHackathon(h)}
                      onEdit={handleEditHackathon}
                      onDelete={handleDeletePrompt}
                      isRegistered={!!getRegistrationForHackathon(hackathon.id)}
                    />
                  ))}
                </div>
              )}

            </section>
          </div>
        ) : (
          /* User Dashboard View */
          <DashboardView
            myHackathons={myHostedHackathons}
            myRegistrations={registrations}
            allHackathons={hackathons}
            onOpenCreateModal={handleOpenCreateModal}
            onSelectHackathon={(h) => setSelectedHackathon(h)}
            onEditHackathon={handleEditHackathon}
            onDeleteHackathon={handleDeletePrompt}
            onBackToExplore={() => setCurrentView('explore')}
          />
        )}
      </main>

      {/* Detail Modal View */}
      {selectedHackathon && (
        <HackathonDetailModal
          hackathon={selectedHackathon}
          onClose={() => setSelectedHackathon(null)}
          onEdit={handleEditHackathon}
          onDelete={handleDeletePrompt}
          userRegistration={getRegistrationForHackathon(selectedHackathon.id)}
        />
      )}

      {/* Create / Edit Hackathon Modal */}
      <CreateEditHackathonModal
        isOpen={isCreateEditOpen}
        onClose={() => {
          setIsCreateEditOpen(false);
          setEditTarget(null);
        }}
        editTarget={editTarget}
      />

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        hackathon={deleteTarget}
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleConfirmDelete}
        isDeleting={isDeleting}
      />

      {/* 14-Slide Project Architecture & Presentation Deck */}
      <PresentationModal
        isOpen={isPresentationOpen}
        onClose={() => setIsPresentationOpen(false)}
      />

      {/* Cyberpunk Footer */}
      <Footer onOpenPresentationModal={() => setIsPresentationOpen(true)} />

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
