import { 
  collection, 
  doc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  where,
  increment,
  writeBatch
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase/config';
import { Hackathon, HackathonRegistration } from '../types/hackathon';

export const INITIAL_HACKATHONS: Omit<Hackathon, 'id'>[] = [
  {
    title: 'CYBERSTORM 2026: Autonomous Security Sprint',
    tagline: 'Elite red-team vs defensive autonomous AI defense systems',
    description: 'Enter the grid. Build next-generation intrusion detection agents, zero-day mitigation protocols, and LLM prompt-hardening systems. 48 hours of intense hacking with real sandbox targets, telemetry capture, and hardware fuzzing nodes. Open to security engineers, AI researchers, and terminal wizards worldwide.',
    category: 'Cybersecurity',
    locationType: 'online',
    location: 'Global Virtual Grid / Discord War Room',
    price: 0,
    prizePool: '$75,000 USD',
    bannerUrl: '/assets/aistudio/hackathon_98a10567.jpg',
    startDate: '2026-11-14',
    endDate: '2026-11-16',
    organizerId: 'seed-admin-01',
    organizerName: 'Ghost Protocol Labs',
    organizerEmail: 'ops@ghostprotocol.dev',
    organizerAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
    websiteUrl: 'https://cyberstorm2026.dev',
    registeredCount: 418,
    tags: ['Cybersecurity', 'Autonomous AI', 'Zero Trust', 'Rust', 'Pen-Testing'],
    rules: 'Teams of 1-4 members. All software must be developed during the 48-hour sprint. Open-source models permitted.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    title: 'NEURAL FORGE: Generative Multi-Agent Summit',
    tagline: 'Architect collaborative swarm systems that solve high-stakes challenges',
    description: 'The era of single chatbots is over. Build swarms of autonomous agents that collaborate, debug, negotiate, and execute complex real-world workflows in healthcare, supply chain logistics, and creative media. Sponsored by top AI research institutes with cloud GPUs provided.',
    category: 'AI & ML',
    locationType: 'hybrid',
    location: 'Moscone Center, San Francisco & Worldwide',
    price: 25,
    prizePool: '$100,000 USD',
    bannerUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
    startDate: '2026-11-20',
    endDate: '2026-11-23',
    organizerId: 'seed-admin-02',
    organizerName: 'Silicon Neural Guild',
    organizerEmail: 'hack@neuralforge.ai',
    organizerAvatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=150&q=80',
    websiteUrl: 'https://neuralforge.ai',
    registeredCount: 890,
    tags: ['Agentic Workflows', 'Multi-Modal', 'Gemini', 'Python', 'Cloud GPUs'],
    rules: 'Submissions must include runnable code, demonstration video, and agent telemetry traces.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    title: 'ZERO KNOWLEDGE ODYSSEY: Web3 Confidentiality',
    tagline: 'Scale zero-knowledge proofs and privacy-preserving decentralized apps',
    description: 'Push cryptographic frontiers. Develop zk-SNARK rollups, private DeFi protocols, decentralized identity primitives, and censorship-resistant communications. Mentorship from leading cryptographers and protocol core developers.',
    category: 'Web3 & Crypto',
    locationType: 'online',
    location: 'Decentralized / Virtual Network',
    price: 0,
    prizePool: '$60,000 USD',
    bannerUrl: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=1200&q=80',
    startDate: '2026-12-05',
    endDate: '2026-12-08',
    organizerId: 'seed-admin-03',
    organizerName: 'CipherZero Foundation',
    organizerEmail: 'grants@cipherzero.org',
    organizerAvatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=150&q=80',
    websiteUrl: 'https://cipherzero.org/odyssey',
    registeredCount: 312,
    tags: ['ZK-Rollups', 'Circom', 'Rust', 'Privacy', 'Smart Contracts'],
    rules: 'Must be open source under MIT or Apache 2.0 license upon final submission.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    title: 'TOKYO SHINJUKU: Cyber-Physical IoT & Robotics Sprint',
    tagline: 'Bridging embedded silicon, edge computing, and real-time sensory grids',
    description: 'Hardware meets street-level intelligence. Build autonomous micro-rovers, smart energy microgrids, wearable biometric telemetry, and edge-AI computer vision nodes. Hardware kits provided for in-person attendees with digital twin simulation for remote builders.',
    category: 'Hardware & IoT',
    locationType: 'in-person',
    location: 'Akihabara Tech Arena, Tokyo, Japan',
    price: 40,
    prizePool: '$45,000 USD',
    bannerUrl: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?auto=format&fit=crop&w=1200&q=80',
    startDate: '2026-12-12',
    endDate: '2026-12-14',
    organizerId: 'seed-admin-04',
    organizerName: 'Tokyo Maker Syndicate',
    organizerEmail: 'contact@tokyosyn.io',
    organizerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
    websiteUrl: 'https://tokyosyn.io/hack2026',
    registeredCount: 220,
    tags: ['Robotics', 'ESP32', 'ROS2', 'Edge AI', 'Computer Vision'],
    rules: 'Physical and virtual hardware prototypes welcome. Safety guidelines strictly enforced in workshop.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    title: 'SYNTHESIS: Global Open-Source Fullstack Jam',
    tagline: 'Build ultra-fast, resilient web platforms using cutting-edge modern stacks',
    description: 'Celebrate high-performance software engineering. Ship production-ready developer tools, collaborative real-time canvases, blazing-fast databases, or developer productivity extensions. Evaluated on architecture, user experience, and technical novelty.',
    category: 'Full-Stack',
    locationType: 'online',
    location: 'Worldwide / GitHub Community',
    price: 0,
    prizePool: '$35,000 USD',
    bannerUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1200&q=80',
    startDate: '2026-12-18',
    endDate: '2026-12-21',
    organizerId: 'seed-admin-05',
    organizerName: 'DevMatrix Core',
    organizerEmail: 'community@devmatrix.net',
    organizerAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80',
    websiteUrl: 'https://devmatrix.net/synthesis',
    registeredCount: 560,
    tags: ['TypeScript', 'Next.js', 'Vite', 'GraphQL', 'Tailwind'],
    rules: 'Any technology stack permitted. Must be deployed live with accessible demo link.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }
];

export const PRESET_BANNERS = [
  { label: 'Cyberpunk Command Station (Ref)', url: '/assets/aistudio/hackathon_98a10567.jpg' },
  { label: 'Neural Matrix & AI Streams', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80' },
  { label: 'Hacker Terminal & Code Matrix', url: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1200&q=80' },
  { label: 'Cryptographic Blocks & Web3', url: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=1200&q=80' },
  { label: 'Cyber Neon Metropolis', url: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?auto=format&fit=crop&w=1200&q=80' },
  { label: 'Quantum Processor Circuit', url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80' }
];

/**
 * Subscribe to real-time hackathons collection updates
 */
export function subscribeToHackathons(
  onSuccess: (hackathons: Hackathon[]) => void,
  onError?: (err: Error) => void
) {
  const collectionRef = collection(db, 'hackathons');
  
  return onSnapshot(
    collectionRef,
    (snapshot) => {
      const items: Hackathon[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        items.push({
          id: docSnap.id,
          title: data.title || '',
          tagline: data.tagline || '',
          description: data.description || '',
          category: data.category || 'Open Innovation',
          locationType: data.locationType || 'online',
          location: data.location || 'Global Virtual',
          price: typeof data.price === 'number' ? data.price : 0,
          prizePool: data.prizePool || 'Prizes Announced Soon',
          bannerUrl: data.bannerUrl || '/assets/aistudio/hackathon_98a10567.jpg',
          startDate: data.startDate || new Date().toISOString().split('T')[0],
          endDate: data.endDate || new Date().toISOString().split('T')[0],
          organizerId: data.organizerId || '',
          organizerName: data.organizerName || 'Anonymous Organizer',
          organizerEmail: data.organizerEmail || '',
          organizerAvatar: data.organizerAvatar,
          websiteUrl: data.websiteUrl || '',
          registeredCount: data.registeredCount || 0,
          tags: Array.isArray(data.tags) ? data.tags : [],
          rules: data.rules || '',
          createdAt: data.createdAt,
          updatedAt: data.updatedAt,
        });
      });

      // Sort by startDate ascending by default
      items.sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime());
      onSuccess(items);
    },
    (error) => {
      console.error('Failed to subscribe to hackathons:', error);
      if (onError) {
        onError(error);
      }
      handleFirestoreError(error, OperationType.LIST, 'hackathons');
    }
  );
}

/**
 * Seed initial hackathons if database has none
 */
export async function seedInitialHackathonsIfEmpty(currentCount: number): Promise<void> {
  if (currentCount > 0) return;
  try {
    const batch = writeBatch(db);
    INITIAL_HACKATHONS.forEach((hackathon, idx) => {
      const docRef = doc(db, 'hackathons', `hackathon-seed-${idx + 1}`);
      batch.set(docRef, hackathon);
    });
    await batch.commit();
  } catch (error) {
    console.warn('Initial seeding note:', error);
  }
}

/**
 * Create a new hackathon
 */
export async function createHackathon(
  data: Omit<Hackathon, 'id' | 'createdAt' | 'updatedAt' | 'registeredCount'>
): Promise<string> {
  const collectionRef = collection(db, 'hackathons');
  const docRef = doc(collectionRef);
  const now = new Date().toISOString();

  const payload: Omit<Hackathon, 'id'> = {
    ...data,
    registeredCount: 1, // Organizer is first registered member
    createdAt: now,
    updatedAt: now,
  };

  try {
    await setDoc(docRef, payload);
    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `hackathons/${docRef.id}`);
  }
}

/**
 * Update an existing hackathon (creator only)
 */
export async function updateHackathon(
  id: string,
  data: Partial<Omit<Hackathon, 'id' | 'organizerId' | 'createdAt'>>
): Promise<void> {
  const docRef = doc(db, 'hackathons', id);
  const payload = {
    ...data,
    updatedAt: new Date().toISOString(),
  };

  try {
    await updateDoc(docRef, payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `hackathons/${id}`);
  }
}

/**
 * Delete a hackathon (creator only)
 */
export async function deleteHackathon(id: string): Promise<void> {
  const docRef = doc(db, 'hackathons', id);
  try {
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `hackathons/${id}`);
  }
}

/**
 * Subscribe to current user's registrations
 */
export function subscribeToUserRegistrations(
  userId: string,
  onSuccess: (registrations: HackathonRegistration[]) => void,
  onError?: (err: Error) => void
) {
  const q = query(collection(db, 'registrations'), where('userId', '==', userId));
  return onSnapshot(
    q,
    (snapshot) => {
      const results: HackathonRegistration[] = [];
      snapshot.forEach((docSnap) => {
        results.push({
          id: docSnap.id,
          ...(docSnap.data() as Omit<HackathonRegistration, 'id'>),
        });
      });
      onSuccess(results);
    },
    (error) => {
      console.error('Error fetching registrations:', error);
      if (onError) onError(error);
      handleFirestoreError(error, OperationType.LIST, 'registrations');
    }
  );
}

/**
 * Register current user for a hackathon
 */
export async function registerForHackathon(
  hackathon: Hackathon,
  userData: {
    userId: string;
    userEmail: string;
    userName: string;
    teamName?: string;
    discordHandle?: string;
    experienceLevel?: string;
  }
): Promise<string> {
  const regId = `${userData.userId}_${hackathon.id}`;
  const regDocRef = doc(db, 'registrations', regId);
  const hackathonRef = doc(db, 'hackathons', hackathon.id);

  const payload: Omit<HackathonRegistration, 'id'> = {
    hackathonId: hackathon.id,
    hackathonTitle: hackathon.title,
    hackathonBanner: hackathon.bannerUrl,
    hackathonStartDate: hackathon.startDate,
    userId: userData.userId,
    userEmail: userData.userEmail,
    userName: userData.userName,
    teamName: userData.teamName || 'Solo Hacker',
    discordHandle: userData.discordHandle || '',
    experienceLevel: userData.experienceLevel || 'Intermediate',
    registeredAt: new Date().toISOString(),
  };

  try {
    await setDoc(regDocRef, payload);
    // increment participant count on hackathon
    await updateDoc(hackathonRef, {
      registeredCount: increment(1),
    }).catch(() => {
      // Ignore if increment fails due to rule permissions
    });
    return regId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `registrations/${regId}`);
  }
}

/**
 * Unregister from a hackathon
 */
export async function unregisterFromHackathon(
  registrationId: string,
  hackathonId: string
): Promise<void> {
  const regDocRef = doc(db, 'registrations', registrationId);
  const hackathonRef = doc(db, 'hackathons', hackathonId);

  try {
    await deleteDoc(regDocRef);
    await updateDoc(hackathonRef, {
      registeredCount: increment(-1),
    }).catch(() => {});
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `registrations/${registrationId}`);
  }
}
